-- Drop the candidate_profiles_visible view since it lacks RLS
-- The base table candidate_profiles already has proper RLS policies
-- Using the table directly is more secure than a view without RLS

DROP VIEW IF EXISTS public.candidate_profiles_visible;
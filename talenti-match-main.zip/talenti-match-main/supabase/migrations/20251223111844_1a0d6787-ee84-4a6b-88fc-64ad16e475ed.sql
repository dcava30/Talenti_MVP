-- Fix the org_users INSERT policy that has a bug (comparing column to itself)
DROP POLICY IF EXISTS "Org admins can manage org users" ON public.org_users;

-- Create corrected policy: allow admins OR allow first user for a NEW organisation
CREATE POLICY "Org admins can manage org users" 
ON public.org_users 
FOR INSERT 
WITH CHECK (
  (user_org_role(auth.uid(), organisation_id) = 'admin'::text) 
  OR 
  (auth.uid() = user_id AND NOT EXISTS (
    SELECT 1 FROM public.org_users ou 
    WHERE ou.organisation_id = org_users.organisation_id
  ))
);
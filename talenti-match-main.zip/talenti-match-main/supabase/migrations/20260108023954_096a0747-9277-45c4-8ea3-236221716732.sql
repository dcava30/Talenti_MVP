-- Drop the existing view and recreate with security_invoker = true
-- This ensures the view respects RLS policies from the underlying candidate_profiles table
DROP VIEW IF EXISTS public.candidate_profiles_visible;

-- Recreate the view with security_invoker enabled
-- This means queries through this view will be checked against the RLS policies
-- of the underlying candidate_profiles table using the invoking user's permissions
CREATE VIEW public.candidate_profiles_visible
WITH (security_invoker = true)
AS
SELECT
  id,
  user_id,
  first_name,
  last_name,
  -- Only show email if visibility_settings allows it
  CASE 
    WHEN (visibility_settings->>'email')::boolean = true THEN email 
    ELSE NULL 
  END as email,
  -- Only show phone if visibility_settings allows it
  CASE 
    WHEN (visibility_settings->>'phone')::boolean = true THEN phone 
    ELSE NULL 
  END as phone,
  -- Location fields - respect visibility_settings
  CASE 
    WHEN (visibility_settings->>'location')::boolean = true THEN suburb 
    ELSE NULL 
  END as suburb,
  CASE 
    WHEN (visibility_settings->>'location')::boolean = true THEN postcode 
    ELSE NULL 
  END as postcode,
  CASE 
    WHEN (visibility_settings->>'location')::boolean = true THEN state 
    ELSE NULL 
  END as state,
  country,
  -- Professional URLs - respect visibility_settings
  CASE 
    WHEN (visibility_settings->>'portfolio')::boolean = true THEN portfolio_url 
    ELSE NULL 
  END as portfolio_url,
  CASE 
    WHEN (visibility_settings->>'linkedin')::boolean = true THEN linkedin_url 
    ELSE NULL 
  END as linkedin_url,
  cv_file_path,
  work_rights,
  availability,
  work_mode,
  profile_visibility,
  gpa_wam,
  cv_uploaded_at,
  created_at,
  updated_at,
  visibility_settings,
  paused_at
FROM public.candidate_profiles;

-- Grant SELECT permission to authenticated users only (not anon)
REVOKE ALL ON public.candidate_profiles_visible FROM anon;
GRANT SELECT ON public.candidate_profiles_visible TO authenticated;
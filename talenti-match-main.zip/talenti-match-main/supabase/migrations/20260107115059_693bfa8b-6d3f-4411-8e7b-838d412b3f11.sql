-- Drop existing SELECT policies on candidate_profiles
DROP POLICY IF EXISTS "Users can view their own profile" ON public.candidate_profiles;
DROP POLICY IF EXISTS "Org members can view applicant profiles" ON public.candidate_profiles;

-- Recreate policies with explicit TO authenticated to deny anonymous/public access
CREATE POLICY "Users can view their own profile"
ON public.candidate_profiles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Org members can view applicant profiles"
ON public.candidate_profiles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE a.candidate_id = candidate_profiles.user_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);
-- Create candidate profiles table
CREATE TABLE public.candidate_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT,
  last_name TEXT,
  email TEXT,
  phone TEXT,
  suburb TEXT,
  postcode TEXT,
  state TEXT,
  country TEXT DEFAULT 'Australia',
  work_rights TEXT, -- citizen, permanent_resident, visa, etc.
  availability TEXT, -- immediate, 2_weeks, 1_month, etc.
  work_mode TEXT, -- onsite, hybrid, remote
  gpa_wam DECIMAL(4,2),
  portfolio_url TEXT,
  linkedin_url TEXT,
  cv_file_path TEXT,
  cv_uploaded_at TIMESTAMPTZ,
  profile_visibility TEXT DEFAULT 'visible', -- visible, hidden, deactivated
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Create employment history table
CREATE TABLE public.employment_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  job_title TEXT NOT NULL,
  company_name TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  is_current BOOLEAN DEFAULT false,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create education table
CREATE TABLE public.education (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  institution TEXT NOT NULL,
  degree TEXT NOT NULL,
  field_of_study TEXT,
  start_date DATE,
  end_date DATE,
  is_current BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create skills table (for candidate skills)
CREATE TABLE public.candidate_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  skill_name TEXT NOT NULL,
  skill_type TEXT NOT NULL, -- hard, soft
  proficiency_level TEXT, -- beginner, intermediate, advanced, expert
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create DEI preferences table (optional, hidden from employers)
CREATE TABLE public.candidate_dei (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  gender TEXT,
  ethnicity TEXT,
  disability_status TEXT,
  veteran_status TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.candidate_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employment_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.education ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candidate_skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candidate_dei ENABLE ROW LEVEL SECURITY;

-- RLS Policies for candidate_profiles
CREATE POLICY "Users can view their own profile"
ON public.candidate_profiles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile"
ON public.candidate_profiles FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.candidate_profiles FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own profile"
ON public.candidate_profiles FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies for employment_history
CREATE POLICY "Users can view their own employment history"
ON public.employment_history FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own employment history"
ON public.employment_history FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own employment history"
ON public.employment_history FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own employment history"
ON public.employment_history FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies for education
CREATE POLICY "Users can view their own education"
ON public.education FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own education"
ON public.education FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own education"
ON public.education FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own education"
ON public.education FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies for candidate_skills
CREATE POLICY "Users can view their own skills"
ON public.candidate_skills FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own skills"
ON public.candidate_skills FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own skills"
ON public.candidate_skills FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own skills"
ON public.candidate_skills FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies for candidate_dei (strictly private)
CREATE POLICY "Users can view their own DEI data"
ON public.candidate_dei FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own DEI data"
ON public.candidate_dei FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own DEI data"
ON public.candidate_dei FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own DEI data"
ON public.candidate_dei FOR DELETE
USING (auth.uid() = user_id);

-- Create storage bucket for CVs
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('candidate-cvs', 'candidate-cvs', false, 10485760, ARRAY['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']);

-- Storage policies for CV uploads
CREATE POLICY "Users can upload their own CV"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'candidate-cvs' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own CV"
ON storage.objects FOR SELECT
USING (bucket_id = 'candidate-cvs' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own CV"
ON storage.objects FOR UPDATE
USING (bucket_id = 'candidate-cvs' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own CV"
ON storage.objects FOR DELETE
USING (bucket_id = 'candidate-cvs' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for candidate_profiles
CREATE TRIGGER update_candidate_profiles_updated_at
BEFORE UPDATE ON public.candidate_profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
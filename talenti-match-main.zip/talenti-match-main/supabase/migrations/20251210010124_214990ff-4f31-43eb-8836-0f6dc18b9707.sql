
-- Create enum for user roles (org vs candidate)
CREATE TYPE public.app_role AS ENUM ('org_admin', 'org_recruiter', 'org_viewer', 'candidate');

-- Create enum for interview status
CREATE TYPE public.interview_status AS ENUM ('invited', 'scheduled', 'in_progress', 'completed', 'cancelled', 'expired');

-- Create enum for invitation status
CREATE TYPE public.invitation_status AS ENUM ('pending', 'sent', 'delivered', 'opened', 'bounced', 'expired');

-- Create enum for job role status
CREATE TYPE public.job_role_status AS ENUM ('draft', 'active', 'paused', 'closed');

-- User roles table (for RBAC)
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Organisations table
CREATE TABLE public.organisations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    industry TEXT,
    website TEXT,
    logo_url TEXT,
    description TEXT,
    values_framework JSONB,
    billing_email TEXT,
    billing_address TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Org users (link users to organisations with roles)
CREATE TABLE public.org_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    organisation_id UUID REFERENCES public.organisations(id) ON DELETE CASCADE NOT NULL,
    role TEXT NOT NULL DEFAULT 'recruiter' CHECK (role IN ('admin', 'recruiter', 'hiring_manager', 'viewer')),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, organisation_id)
);

-- Job roles table
CREATE TABLE public.job_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organisation_id UUID REFERENCES public.organisations(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    department TEXT,
    industry TEXT,
    work_type TEXT CHECK (work_type IN ('onsite', 'hybrid', 'remote')),
    location TEXT,
    salary_range_min INTEGER,
    salary_range_max INTEGER,
    employment_type TEXT CHECK (employment_type IN ('full_time', 'part_time', 'contract', 'casual')),
    description TEXT,
    requirements JSONB,
    interview_structure JSONB,
    scoring_rubric JSONB,
    status job_role_status NOT NULL DEFAULT 'draft',
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Applications (candidate applying to a role)
CREATE TABLE public.applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    candidate_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    job_role_id UUID REFERENCES public.job_roles(id) ON DELETE CASCADE NOT NULL,
    status TEXT NOT NULL DEFAULT 'applied' CHECK (status IN ('applied', 'shortlisted', 'invited', 'interviewed', 'scoring', 'reviewed', 'rejected', 'hired')),
    match_score NUMERIC,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (candidate_id, job_role_id)
);

-- Invitations table
CREATE TABLE public.invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    application_id UUID REFERENCES public.applications(id) ON DELETE CASCADE NOT NULL,
    token TEXT NOT NULL UNIQUE,
    status invitation_status NOT NULL DEFAULT 'pending',
    email_template TEXT,
    sent_at TIMESTAMP WITH TIME ZONE,
    opened_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Interviews table
CREATE TABLE public.interviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    application_id UUID REFERENCES public.applications(id) ON DELETE CASCADE NOT NULL,
    status interview_status NOT NULL DEFAULT 'invited',
    started_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    recording_url TEXT,
    anti_cheat_signals JSONB DEFAULT '[]'::jsonb,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Transcript segments table
CREATE TABLE public.transcript_segments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    interview_id UUID REFERENCES public.interviews(id) ON DELETE CASCADE NOT NULL,
    speaker TEXT NOT NULL CHECK (speaker IN ('ai', 'candidate')),
    content TEXT NOT NULL,
    start_time_ms INTEGER NOT NULL,
    end_time_ms INTEGER,
    confidence NUMERIC,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Score dimensions table
CREATE TABLE public.score_dimensions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    interview_id UUID REFERENCES public.interviews(id) ON DELETE CASCADE NOT NULL,
    dimension TEXT NOT NULL,
    score NUMERIC NOT NULL CHECK (score >= 0 AND score <= 10),
    weight NUMERIC DEFAULT 1.0,
    evidence TEXT,
    cited_quotes JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Interview scores (overall)
CREATE TABLE public.interview_scores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    interview_id UUID REFERENCES public.interviews(id) ON DELETE CASCADE NOT NULL UNIQUE,
    overall_score NUMERIC CHECK (overall_score >= 0 AND overall_score <= 100),
    narrative_summary TEXT,
    candidate_feedback TEXT,
    anti_cheat_risk_level TEXT CHECK (anti_cheat_risk_level IN ('low', 'medium', 'high')),
    scored_by TEXT DEFAULT 'ai',
    human_override BOOLEAN DEFAULT false,
    human_override_by UUID REFERENCES auth.users(id),
    human_override_reason TEXT,
    model_version TEXT,
    prompt_version TEXT,
    rubric_version TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Audit log for governance
CREATE TABLE public.audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id),
    organisation_id UUID REFERENCES public.organisations(id),
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organisations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.org_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transcript_segments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.score_dimensions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interview_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Security definer function to check if user belongs to an org
CREATE OR REPLACE FUNCTION public.user_belongs_to_org(_user_id UUID, _org_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_users
    WHERE user_id = _user_id AND organisation_id = _org_id
  )
$$;

-- Security definer function to check org role
CREATE OR REPLACE FUNCTION public.user_org_role(_user_id UUID, _org_id UUID)
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.org_users
  WHERE user_id = _user_id AND organisation_id = _org_id
  LIMIT 1
$$;

-- Security definer function to get user's org id
CREATE OR REPLACE FUNCTION public.get_user_org_id(_user_id UUID)
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT organisation_id FROM public.org_users
  WHERE user_id = _user_id
  LIMIT 1
$$;

-- Security definer function to check if user has app role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

-- RLS Policies for organisations
CREATE POLICY "Org members can view their organisation"
ON public.organisations FOR SELECT
USING (public.user_belongs_to_org(auth.uid(), id));

CREATE POLICY "Org admins can update their organisation"
ON public.organisations FOR UPDATE
USING (public.user_org_role(auth.uid(), id) = 'admin');

CREATE POLICY "Authenticated users can create organisations"
ON public.organisations FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

-- RLS Policies for org_users
CREATE POLICY "Org members can view org users"
ON public.org_users FOR SELECT
USING (public.user_belongs_to_org(auth.uid(), organisation_id));

CREATE POLICY "Org admins can manage org users"
ON public.org_users FOR INSERT
WITH CHECK (public.user_org_role(auth.uid(), organisation_id) = 'admin' OR 
            (NOT EXISTS (SELECT 1 FROM public.org_users WHERE organisation_id = org_users.organisation_id)));

CREATE POLICY "Org admins can update org users"
ON public.org_users FOR UPDATE
USING (public.user_org_role(auth.uid(), organisation_id) = 'admin');

CREATE POLICY "Org admins can delete org users"
ON public.org_users FOR DELETE
USING (public.user_org_role(auth.uid(), organisation_id) = 'admin');

-- RLS Policies for job_roles
CREATE POLICY "Org members can view their job roles"
ON public.job_roles FOR SELECT
USING (public.user_belongs_to_org(auth.uid(), organisation_id));

CREATE POLICY "Org recruiters and admins can create job roles"
ON public.job_roles FOR INSERT
WITH CHECK (public.user_org_role(auth.uid(), organisation_id) IN ('admin', 'recruiter', 'hiring_manager'));

CREATE POLICY "Org recruiters and admins can update job roles"
ON public.job_roles FOR UPDATE
USING (public.user_org_role(auth.uid(), organisation_id) IN ('admin', 'recruiter', 'hiring_manager'));

CREATE POLICY "Org admins can delete job roles"
ON public.job_roles FOR DELETE
USING (public.user_org_role(auth.uid(), organisation_id) = 'admin');

-- RLS Policies for applications
CREATE POLICY "Candidates can view their own applications"
ON public.applications FOR SELECT
USING (auth.uid() = candidate_id);

CREATE POLICY "Org members can view applications for their roles"
ON public.applications FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.job_roles jr
    WHERE jr.id = job_role_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

CREATE POLICY "Candidates can create applications"
ON public.applications FOR INSERT
WITH CHECK (auth.uid() = candidate_id);

CREATE POLICY "Org members can update application status"
ON public.applications FOR UPDATE
USING (EXISTS (
    SELECT 1 FROM public.job_roles jr
    WHERE jr.id = job_role_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

-- RLS Policies for invitations
CREATE POLICY "Org members can view invitations"
ON public.invitations FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.applications a
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE a.id = application_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

CREATE POLICY "Org members can create invitations"
ON public.invitations FOR INSERT
WITH CHECK (EXISTS (
    SELECT 1 FROM public.applications a
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE a.id = application_id
    AND public.user_org_role(auth.uid(), jr.organisation_id) IN ('admin', 'recruiter', 'hiring_manager')
));

-- RLS Policies for interviews
CREATE POLICY "Candidates can view their own interviews"
ON public.interviews FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.applications a
    WHERE a.id = application_id AND a.candidate_id = auth.uid()
));

CREATE POLICY "Org members can view interviews for their roles"
ON public.interviews FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.applications a
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE a.id = application_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

CREATE POLICY "System can create interviews"
ON public.interviews FOR INSERT
WITH CHECK (EXISTS (
    SELECT 1 FROM public.applications a
    WHERE a.id = application_id AND a.candidate_id = auth.uid()
));

CREATE POLICY "System can update interviews"
ON public.interviews FOR UPDATE
USING (EXISTS (
    SELECT 1 FROM public.applications a
    WHERE a.id = application_id AND a.candidate_id = auth.uid()
) OR EXISTS (
    SELECT 1 FROM public.applications a
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE a.id = application_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

-- RLS Policies for transcript_segments
CREATE POLICY "Candidates can view their own transcripts"
ON public.transcript_segments FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    WHERE i.id = interview_id AND a.candidate_id = auth.uid()
));

CREATE POLICY "Org members can view transcripts"
ON public.transcript_segments FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE i.id = interview_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

CREATE POLICY "System can insert transcripts"
ON public.transcript_segments FOR INSERT
WITH CHECK (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    WHERE i.id = interview_id AND a.candidate_id = auth.uid()
));

-- RLS Policies for score_dimensions
CREATE POLICY "Org members can view score dimensions"
ON public.score_dimensions FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE i.id = interview_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

-- RLS Policies for interview_scores
CREATE POLICY "Candidates can view their own scores"
ON public.interview_scores FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    WHERE i.id = interview_id AND a.candidate_id = auth.uid()
));

CREATE POLICY "Org members can view scores"
ON public.interview_scores FOR SELECT
USING (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE i.id = interview_id
    AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
));

CREATE POLICY "Org members can update scores for override"
ON public.interview_scores FOR UPDATE
USING (EXISTS (
    SELECT 1 FROM public.interviews i
    JOIN public.applications a ON a.id = i.application_id
    JOIN public.job_roles jr ON jr.id = a.job_role_id
    WHERE i.id = interview_id
    AND public.user_org_role(auth.uid(), jr.organisation_id) IN ('admin', 'recruiter', 'hiring_manager')
));

-- RLS Policies for audit_log
CREATE POLICY "Org admins can view audit logs"
ON public.audit_log FOR SELECT
USING (public.user_org_role(auth.uid(), organisation_id) = 'admin');

CREATE POLICY "System can insert audit logs"
ON public.audit_log FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

-- Create indexes for performance
CREATE INDEX idx_org_users_user_id ON public.org_users(user_id);
CREATE INDEX idx_org_users_org_id ON public.org_users(organisation_id);
CREATE INDEX idx_job_roles_org_id ON public.job_roles(organisation_id);
CREATE INDEX idx_job_roles_status ON public.job_roles(status);
CREATE INDEX idx_applications_candidate ON public.applications(candidate_id);
CREATE INDEX idx_applications_role ON public.applications(job_role_id);
CREATE INDEX idx_interviews_application ON public.interviews(application_id);
CREATE INDEX idx_interviews_status ON public.interviews(status);
CREATE INDEX idx_transcript_segments_interview ON public.transcript_segments(interview_id);
CREATE INDEX idx_score_dimensions_interview ON public.score_dimensions(interview_id);
CREATE INDEX idx_audit_log_org ON public.audit_log(organisation_id);
CREATE INDEX idx_audit_log_user ON public.audit_log(user_id);

-- Add triggers for updated_at
CREATE TRIGGER update_organisations_updated_at
BEFORE UPDATE ON public.organisations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_job_roles_updated_at
BEFORE UPDATE ON public.job_roles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_applications_updated_at
BEFORE UPDATE ON public.applications
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_interviews_updated_at
BEFORE UPDATE ON public.interviews
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_interview_scores_updated_at
BEFORE UPDATE ON public.interview_scores
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

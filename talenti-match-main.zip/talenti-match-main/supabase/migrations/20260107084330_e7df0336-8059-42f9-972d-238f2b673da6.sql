-- Drop the overly permissive public access policy
DROP POLICY IF EXISTS "Anyone can view active job roles" ON public.job_roles;

-- Create a new policy that requires authentication to view active job roles
-- This allows authenticated candidates to browse available positions
CREATE POLICY "Authenticated users can view active job roles"
ON public.job_roles
FOR SELECT
TO authenticated
USING (status = 'active');
-- Create practice_interviews table for storing practice session data
CREATE TABLE public.practice_interviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  sample_role_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'not_started',
  started_at TIMESTAMP WITH TIME ZONE,
  ended_at TIMESTAMP WITH TIME ZONE,
  duration_seconds INTEGER,
  feedback JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.practice_interviews ENABLE ROW LEVEL SECURITY;

-- RLS policies for practice_interviews
CREATE POLICY "Users can view their own practice interviews"
ON public.practice_interviews FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own practice interviews"
ON public.practice_interviews FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own practice interviews"
ON public.practice_interviews FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own practice interviews"
ON public.practice_interviews FOR DELETE
USING (auth.uid() = user_id);

-- Add visibility_settings column to candidate_profiles
ALTER TABLE public.candidate_profiles 
ADD COLUMN IF NOT EXISTS visibility_settings JSONB DEFAULT '{
  "name": true,
  "email": false,
  "phone": false,
  "location": true,
  "education": true,
  "employment": true,
  "skills": true,
  "portfolio": true,
  "linkedin": true
}'::jsonb;

-- Add paused_at column for profile pausing functionality
ALTER TABLE public.candidate_profiles 
ADD COLUMN IF NOT EXISTS paused_at TIMESTAMP WITH TIME ZONE;
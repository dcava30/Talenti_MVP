-- Add SELECT policies for org members to view candidate data when they have applications
-- This enables recruiters to review candidate profiles for their job roles

-- candidate_profiles: Allow org members to view profiles of candidates who applied to their roles
CREATE POLICY "Org members can view applicant profiles"
ON public.candidate_profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE a.candidate_id = candidate_profiles.user_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);

-- candidate_skills: Allow org members to view skills of applicants
CREATE POLICY "Org members can view applicant skills"
ON public.candidate_skills
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE a.candidate_id = candidate_skills.user_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);

-- education: Allow org members to view education of applicants
CREATE POLICY "Org members can view applicant education"
ON public.education
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE a.candidate_id = education.user_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);

-- employment_history: Allow org members to view employment history of applicants
CREATE POLICY "Org members can view applicant employment"
ON public.employment_history
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE a.candidate_id = employment_history.user_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);

-- candidate_dei: Allow org admins to view DEI data for reporting (anonymized access)
CREATE POLICY "Org admins can view applicant DEI for reporting"
ON public.candidate_dei
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE a.candidate_id = candidate_dei.user_id
    AND user_org_role(auth.uid(), jr.organisation_id) = 'admin'
  )
);

-- Candidates can view their own scores (already exists but adding for completeness)
-- No change needed for interview_scores - policies exist

-- Candidates can view score dimensions for their interviews
CREATE POLICY "Candidates can view their own score dimensions"
ON public.score_dimensions
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM interviews i
    JOIN applications a ON a.id = i.application_id
    WHERE i.id = score_dimensions.interview_id
    AND a.candidate_id = auth.uid()
  )
);

-- Candidates can view their own invitations
CREATE POLICY "Candidates can view their own invitations"
ON public.invitations
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    WHERE a.id = invitations.application_id
    AND a.candidate_id = auth.uid()
  )
);

-- Allow updating invitation status when candidate opens it
CREATE POLICY "Candidates can update invitation status"
ON public.invitations
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM applications a
    WHERE a.id = invitations.application_id
    AND a.candidate_id = auth.uid()
  )
);

-- Candidates can view active job roles (for browsing/applying)
CREATE POLICY "Anyone can view active job roles"
ON public.job_roles
FOR SELECT
USING (status = 'active');

-- Allow candidates to view the organisation for jobs they're applying to
CREATE POLICY "Candidates can view org for their applications"
ON public.organisations
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM applications a
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE jr.organisation_id = organisations.id
    AND a.candidate_id = auth.uid()
  )
);
-- Create data deletion requests table for GDPR compliance
CREATE TABLE public.data_deletion_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  request_type TEXT NOT NULL DEFAULT 'full_deletion', -- 'full_deletion', 'recording_only', 'anonymize'
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  reason TEXT,
  requested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  processed_at TIMESTAMP WITH TIME ZONE,
  processed_by TEXT, -- 'system' or admin user_id
  notes TEXT
);

-- Enable RLS
ALTER TABLE public.data_deletion_requests ENABLE ROW LEVEL SECURITY;

-- Candidates can create deletion requests for themselves
CREATE POLICY "Users can create their own deletion requests"
ON public.data_deletion_requests
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Candidates can view their own deletion requests
CREATE POLICY "Users can view their own deletion requests"
ON public.data_deletion_requests
FOR SELECT
USING (auth.uid() = user_id);

-- Create index for efficient querying
CREATE INDEX idx_deletion_requests_status ON public.data_deletion_requests(status);
CREATE INDEX idx_deletion_requests_user_id ON public.data_deletion_requests(user_id);

-- Add retention_days column to organisations for configurable retention
ALTER TABLE public.organisations 
ADD COLUMN IF NOT EXISTS recording_retention_days INTEGER DEFAULT 60;

-- Add deleted_at column to interviews for soft delete tracking
ALTER TABLE public.interviews
ADD COLUMN IF NOT EXISTS recording_deleted_at TIMESTAMP WITH TIME ZONE;
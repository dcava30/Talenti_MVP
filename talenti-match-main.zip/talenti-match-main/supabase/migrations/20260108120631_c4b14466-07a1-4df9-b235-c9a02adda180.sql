-- Drop the existing overly restrictive policy
DROP POLICY IF EXISTS "Users can view their own CV" ON storage.objects;

-- Create a comprehensive policy that allows:
-- 1. Candidates to view their own CVs
-- 2. Org members to view CVs of candidates who applied to their job roles
CREATE POLICY "Users and org members can view CVs"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'candidate-cvs'
  AND (
    -- Candidate can view their own CV
    auth.uid()::text = (storage.foldername(name))[1]
    OR
    -- Org members can view CVs of candidates who applied to their roles
    EXISTS (
      SELECT 1 
      FROM public.candidate_profiles cp
      JOIN public.applications a ON a.candidate_id = cp.user_id
      JOIN public.job_roles jr ON jr.id = a.job_role_id
      WHERE cp.cv_file_path = name
      AND public.user_belongs_to_org(auth.uid(), jr.organisation_id)
    )
  )
);
-- Drop and recreate view with SECURITY INVOKER to satisfy linter
-- The view uses auth.uid() which works with INVOKER since caller's session is used
DROP VIEW IF EXISTS public.candidate_profiles_visible;

CREATE VIEW public.candidate_profiles_visible
WITH (security_invoker = true)
AS
SELECT 
  id,
  user_id,
  first_name,
  last_name,
  CASE 
    WHEN auth.uid() = user_id THEN email
    WHEN COALESCE((visibility_settings->>'email')::boolean, false) = true THEN email
    ELSE NULL
  END as email,
  CASE 
    WHEN auth.uid() = user_id THEN phone
    WHEN COALESCE((visibility_settings->>'phone')::boolean, false) = true THEN phone
    ELSE NULL
  END as phone,
  CASE 
    WHEN auth.uid() = user_id THEN suburb
    WHEN COALESCE((visibility_settings->>'location')::boolean, true) = true THEN suburb
    ELSE NULL
  END as suburb,
  CASE 
    WHEN auth.uid() = user_id THEN postcode
    WHEN COALESCE((visibility_settings->>'location')::boolean, true) = true THEN postcode
    ELSE NULL
  END as postcode,
  CASE 
    WHEN auth.uid() = user_id THEN state
    WHEN COALESCE((visibility_settings->>'location')::boolean, true) = true THEN state
    ELSE NULL
  END as state,
  country,
  CASE 
    WHEN auth.uid() = user_id THEN portfolio_url
    WHEN COALESCE((visibility_settings->>'portfolio')::boolean, true) = true THEN portfolio_url
    ELSE NULL
  END as portfolio_url,
  CASE 
    WHEN auth.uid() = user_id THEN linkedin_url
    WHEN COALESCE((visibility_settings->>'linkedin')::boolean, true) = true THEN linkedin_url
    ELSE NULL
  END as linkedin_url,
  gpa_wam,
  cv_file_path,
  cv_uploaded_at,
  created_at,
  updated_at,
  visibility_settings,
  paused_at,
  work_rights,
  availability,
  work_mode,
  profile_visibility
FROM public.candidate_profiles;

GRANT SELECT ON public.candidate_profiles_visible TO authenticated;
-- Add INSERT policy for score_dimensions table
-- Allows authenticated users to insert score dimensions for interviews they own (as candidate)
-- or for interviews in their organization's job roles (as org member)

CREATE POLICY "System can insert score dimensions for own interviews"
ON public.score_dimensions
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM interviews i
    JOIN applications a ON a.id = i.application_id
    WHERE i.id = score_dimensions.interview_id
    AND a.candidate_id = auth.uid()
  )
);

CREATE POLICY "Org members can insert score dimensions for their roles"
ON public.score_dimensions
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM interviews i
    JOIN applications a ON a.id = i.application_id
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE i.id = score_dimensions.interview_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);
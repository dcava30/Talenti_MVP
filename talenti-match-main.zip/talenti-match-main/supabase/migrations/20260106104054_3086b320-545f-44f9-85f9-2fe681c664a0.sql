-- Allow system to insert interview scores for candidate's own interviews
-- This enables the scoring edge function to save scores
CREATE POLICY "System can insert scores for own interviews"
ON public.interview_scores
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM interviews i
    JOIN applications a ON a.id = i.application_id
    WHERE i.id = interview_scores.interview_id
    AND a.candidate_id = auth.uid()
  )
);

-- Also allow org members to insert scores (for manual scoring scenarios)
CREATE POLICY "Org members can insert scores for their roles"
ON public.interview_scores
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM interviews i
    JOIN applications a ON a.id = i.application_id
    JOIN job_roles jr ON jr.id = a.job_role_id
    WHERE i.id = interview_scores.interview_id
    AND user_belongs_to_org(auth.uid(), jr.organisation_id)
  )
);
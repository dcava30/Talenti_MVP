import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { action } = await req.json();
    
    console.log(`Data retention cleanup started with action: ${action}`);

    if (action === "cleanup_recordings") {
      // Clean up old interview recordings based on organisation retention settings
      const result = await cleanupOldRecordings(supabase);
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "process_deletion_requests") {
      // Process pending data deletion requests
      const result = await processDeletionRequests(supabase);
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Invalid action. Use 'cleanup_recordings' or 'process_deletion_requests'" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error in data retention cleanup:", errorMessage);
    return new Response(
      JSON.stringify({ error: "An error occurred processing your request" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function cleanupOldRecordings(supabase: any) {
  console.log("Starting cleanup of old interview recordings...");
  
  // Get all organisations with their retention settings
  const { data: orgs, error: orgsError } = await supabase
    .from("organisations")
    .select("id, name, recording_retention_days");

  if (orgsError) {
    console.error("Error fetching organisations:", orgsError);
    throw orgsError;
  }

  let totalDeleted = 0;
  const results: any[] = [];

  for (const org of orgs || []) {
    const retentionDays = org.recording_retention_days || 60;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

    console.log(`Processing org ${org.name}: retention=${retentionDays} days, cutoff=${cutoffDate.toISOString()}`);

    // Find interviews with recordings older than retention period
    const { data: interviews, error: interviewsError } = await supabase
      .from("interviews")
      .select(`
        id,
        recording_url,
        ended_at,
        applications!inner(
          job_roles!inner(organisation_id)
        )
      `)
      .eq("applications.job_roles.organisation_id", org.id)
      .not("recording_url", "is", null)
      .is("recording_deleted_at", null)
      .lt("ended_at", cutoffDate.toISOString());

    if (interviewsError) {
      console.error(`Error fetching interviews for org ${org.id}:`, interviewsError);
      continue;
    }

    for (const interview of interviews || []) {
      try {
        // Delete recording from storage if it exists
        if (interview.recording_url) {
          const filePath = extractFilePathFromUrl(interview.recording_url);
          if (filePath) {
            const { error: storageError } = await supabase.storage
              .from("recordings")
              .remove([filePath]);
            
            if (storageError) {
              console.error(`Error deleting recording for interview ${interview.id}:`, storageError);
            }
          }
        }

        // Mark recording as deleted
        const { error: updateError } = await supabase
          .from("interviews")
          .update({ 
            recording_url: null,
            recording_deleted_at: new Date().toISOString()
          })
          .eq("id", interview.id);

        if (updateError) {
          console.error(`Error updating interview ${interview.id}:`, updateError);
        } else {
          totalDeleted++;
          console.log(`Deleted recording for interview ${interview.id}`);
        }
      } catch (err) {
        console.error(`Error processing interview ${interview.id}:`, err);
      }
    }

    results.push({
      organisation: org.name,
      retentionDays,
      interviewsProcessed: interviews?.length || 0,
    });
  }

  console.log(`Cleanup completed. Total recordings deleted: ${totalDeleted}`);
  
  return {
    success: true,
    totalDeleted,
    organisationResults: results,
    processedAt: new Date().toISOString(),
  };
}

async function processDeletionRequests(supabase: any) {
  console.log("Processing pending deletion requests...");

  // Get pending deletion requests
  const { data: requests, error: requestsError } = await supabase
    .from("data_deletion_requests")
    .select("*")
    .eq("status", "pending")
    .order("requested_at", { ascending: true });

  if (requestsError) {
    console.error("Error fetching deletion requests:", requestsError);
    throw requestsError;
  }

  const results: any[] = [];

  for (const request of requests || []) {
    console.log(`Processing deletion request ${request.id} for user ${request.user_id}`);
    
    try {
      // Update status to processing
      await supabase
        .from("data_deletion_requests")
        .update({ status: "processing" })
        .eq("id", request.id);

      if (request.request_type === "full_deletion") {
        await performFullDeletion(supabase, request.user_id);
      } else if (request.request_type === "recording_only") {
        await deleteUserRecordings(supabase, request.user_id);
      } else if (request.request_type === "anonymize") {
        await anonymizeUserData(supabase, request.user_id);
      }

      // Mark request as completed
      await supabase
        .from("data_deletion_requests")
        .update({ 
          status: "completed",
          processed_at: new Date().toISOString(),
          processed_by: "system"
        })
        .eq("id", request.id);

      results.push({ requestId: request.id, status: "completed" });
      console.log(`Deletion request ${request.id} completed successfully`);
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      console.error(`Error processing request ${request.id}:`, errorMessage);
      
      await supabase
        .from("data_deletion_requests")
        .update({ 
          status: "failed",
          processed_at: new Date().toISOString(),
          notes: errorMessage
        })
        .eq("id", request.id);

      results.push({ requestId: request.id, status: "failed", error: errorMessage });
    }
  }

  return {
    success: true,
    requestsProcessed: results.length,
    results,
    processedAt: new Date().toISOString(),
  };
}

async function performFullDeletion(supabase: any, userId: string) {
  console.log(`Performing full deletion for user ${userId}`);

  // Delete in order respecting foreign key constraints
  
  // 1. Delete transcript segments for user's interviews
  const { data: applications } = await supabase
    .from("applications")
    .select("id")
    .eq("candidate_id", userId);

  const applicationIds = applications?.map((a: any) => a.id) || [];

  if (applicationIds.length > 0) {
    const { data: interviews } = await supabase
      .from("interviews")
      .select("id, recording_url")
      .in("application_id", applicationIds);

    const interviewIds = interviews?.map((i: any) => i.id) || [];

    if (interviewIds.length > 0) {
      // Delete transcript segments
      await supabase
        .from("transcript_segments")
        .delete()
        .in("interview_id", interviewIds);

      // Delete score dimensions
      await supabase
        .from("score_dimensions")
        .delete()
        .in("interview_id", interviewIds);

      // Delete interview scores
      await supabase
        .from("interview_scores")
        .delete()
        .in("interview_id", interviewIds);

      // Delete recordings from storage
      for (const interview of interviews || []) {
        if (interview.recording_url) {
          const filePath = extractFilePathFromUrl(interview.recording_url);
          if (filePath) {
            await supabase.storage.from("recordings").remove([filePath]);
          }
        }
      }

      // Delete interviews
      await supabase
        .from("interviews")
        .delete()
        .in("application_id", applicationIds);
    }

    // Delete invitations
    await supabase
      .from("invitations")
      .delete()
      .in("application_id", applicationIds);

    // Delete applications
    await supabase
      .from("applications")
      .delete()
      .eq("candidate_id", userId);
  }

  // 2. Delete practice interviews
  await supabase
    .from("practice_interviews")
    .delete()
    .eq("user_id", userId);

  // 3. Delete candidate skills
  await supabase
    .from("candidate_skills")
    .delete()
    .eq("user_id", userId);

  // 4. Delete education
  await supabase
    .from("education")
    .delete()
    .eq("user_id", userId);

  // 5. Delete employment history
  await supabase
    .from("employment_history")
    .delete()
    .eq("user_id", userId);

  // 6. Delete DEI data
  await supabase
    .from("candidate_dei")
    .delete()
    .eq("user_id", userId);

  // 7. Delete CV from storage
  const { data: profile } = await supabase
    .from("candidate_profiles")
    .select("cv_file_path")
    .eq("user_id", userId)
    .maybeSingle();

  if (profile?.cv_file_path) {
    await supabase.storage.from("candidate-cvs").remove([profile.cv_file_path]);
  }

  // 8. Delete candidate profile
  await supabase
    .from("candidate_profiles")
    .delete()
    .eq("user_id", userId);

  // 9. Delete user roles
  await supabase
    .from("user_roles")
    .delete()
    .eq("user_id", userId);

  console.log(`Full deletion completed for user ${userId}`);
}

async function deleteUserRecordings(supabase: any, userId: string) {
  console.log(`Deleting recordings only for user ${userId}`);

  const { data: applications } = await supabase
    .from("applications")
    .select("id")
    .eq("candidate_id", userId);

  const applicationIds = applications?.map((a: any) => a.id) || [];

  if (applicationIds.length > 0) {
    const { data: interviews } = await supabase
      .from("interviews")
      .select("id, recording_url")
      .in("application_id", applicationIds)
      .not("recording_url", "is", null);

    for (const interview of interviews || []) {
      if (interview.recording_url) {
        const filePath = extractFilePathFromUrl(interview.recording_url);
        if (filePath) {
          await supabase.storage.from("recordings").remove([filePath]);
        }
      }

      await supabase
        .from("interviews")
        .update({ 
          recording_url: null,
          recording_deleted_at: new Date().toISOString()
        })
        .eq("id", interview.id);
    }
  }

  console.log(`Recording deletion completed for user ${userId}`);
}

async function anonymizeUserData(supabase: any, userId: string) {
  console.log(`Anonymizing data for user ${userId}`);

  // Anonymize profile data
  await supabase
    .from("candidate_profiles")
    .update({
      first_name: "Anonymized",
      last_name: "User",
      email: `anonymized-${userId.substring(0, 8)}@deleted.local`,
      phone: null,
      linkedin_url: null,
      portfolio_url: null,
      suburb: null,
      postcode: null,
      state: null,
      country: null,
    })
    .eq("user_id", userId);

  // Delete DEI data entirely
  await supabase
    .from("candidate_dei")
    .delete()
    .eq("user_id", userId);

  console.log(`Anonymization completed for user ${userId}`);
}

function extractFilePathFromUrl(url: string): string | null {
  try {
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split("/");
    // Get the file path after the bucket name
    const bucketIndex = pathParts.findIndex(p => p === "recordings" || p === "candidate-cvs");
    if (bucketIndex >= 0) {
      return pathParts.slice(bucketIndex + 1).join("/");
    }
    return null;
  } catch {
    return null;
  }
}

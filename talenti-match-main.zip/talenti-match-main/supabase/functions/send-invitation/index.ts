import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendInvitationRequest {
  applicationId: string;
  candidateEmail: string;
  roleTitle: string;
  companyName: string;
  expiresInDays?: number;
}

function generateSecureToken(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Verify user authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized - authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create client with user's auth for permission checks
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the user is authenticated
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      console.error('Auth verification failed:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized - invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { applicationId, candidateEmail, roleTitle, companyName, expiresInDays = 7 }: SendInvitationRequest = await req.json();

    console.log(`User ${user.id} sending invitation for application:`, applicationId);

    // Verify user has permission to invite for this application
    // The user must be an org member with recruiter/admin role for the application's job role
    const { data: application, error: appError } = await userClient
      .from('applications')
      .select(`
        id,
        job_role_id,
        job_roles!inner(
          organisation_id
        )
      `)
      .eq('id', applicationId)
      .maybeSingle();

    if (appError || !application) {
      console.error('Application not found or access denied:', appError);
      return new Response(
        JSON.stringify({ error: 'Application not found or access denied' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if user is org member with invite permission
    const orgId = (application.job_roles as any).organisation_id;
    const { data: orgUser, error: orgError } = await userClient
      .from('org_users')
      .select('role')
      .eq('user_id', user.id)
      .eq('organisation_id', orgId)
      .maybeSingle();

    if (orgError || !orgUser) {
      console.error('User not member of organization:', orgError);
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions - not an organization member' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Only admins, recruiters, and org_admin can send invitations
    const allowedRoles = ['admin', 'org_admin', 'recruiter', 'hiring_manager'];
    if (!allowedRoles.includes(orgUser.role)) {
      console.error(`User role '${orgUser.role}' not authorized to send invitations`);
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions - role not authorized' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Authorization passed for user ${user.id} with role ${orgUser.role}`);

    // Now use service role client for invitation creation (bypasses RLS for insert)
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Generate secure token
    const token = generateSecureToken();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + expiresInDays);

    // Create invitation record
    const { data: invitation, error: invitationError } = await supabase
      .from("invitations")
      .insert({
        application_id: applicationId,
        token: token,
        expires_at: expiresAt.toISOString(),
        status: "pending",
        email_template: "standard",
      })
      .select()
      .single();

    if (invitationError) {
      console.error("Error creating invitation:", invitationError);
      return new Response(
        JSON.stringify({ error: "Failed to create invitation" }),
        { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log("Created invitation:", invitation.id);

    // Build interview URL
    const baseUrl = Deno.env.get("SITE_URL") || "https://talenti.lovable.app";
    const interviewUrl = `${baseUrl}/invite/${token}`;

    // Send email via Resend
    const emailResponse = await resend.emails.send({
      from: "Talenti <onboarding@resend.dev>",
      to: [candidateEmail],
      subject: `Interview Invitation: ${roleTitle} at ${companyName}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 32px;">
            <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #6366f1, #8b5cf6); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px;">
              <span style="color: white; font-weight: bold; font-size: 24px;">T</span>
            </div>
            <h1 style="margin: 0; font-size: 24px; color: #111;">Talenti</h1>
          </div>

          <h2 style="margin-bottom: 16px;">You're Invited to Interview!</h2>
          
          <p>Hello,</p>
          
          <p>You've been invited to complete an AI-powered interview for the <strong>${roleTitle}</strong> position at <strong>${companyName}</strong>.</p>
          
          <div style="background: #f8f9fa; border-radius: 12px; padding: 24px; margin: 24px 0;">
            <h3 style="margin-top: 0; margin-bottom: 16px;">What to Expect</h3>
            <ul style="margin: 0; padding-left: 20px;">
              <li style="margin-bottom: 8px;">10-15 minute voice interview</li>
              <li style="margin-bottom: 8px;">AI interviewer will ask role-specific questions</li>
              <li style="margin-bottom: 8px;">Requires camera and microphone access</li>
              <li style="margin-bottom: 8px;">Find a quiet, well-lit space</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 32px 0;">
            <a href="${interviewUrl}" style="display: inline-block; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; text-decoration: none; padding: 16px 32px; border-radius: 8px; font-weight: 600; font-size: 16px;">
              Start Your Interview
            </a>
          </div>
          
          <p style="color: #666; font-size: 14px;">
            This invitation expires on <strong>${expiresAt.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</strong>.
          </p>
          
          <p style="color: #666; font-size: 14px;">
            If the button doesn't work, copy and paste this link into your browser:<br>
            <a href="${interviewUrl}" style="color: #6366f1; word-break: break-all;">${interviewUrl}</a>
          </p>
          
          <hr style="border: none; border-top: 1px solid #eee; margin: 32px 0;">
          
          <p style="color: #999; font-size: 12px; text-align: center;">
            Powered by Talenti AI Interviews<br>
            This is an automated message. Please do not reply.
          </p>
        </body>
        </html>
      `,
    });

    console.log("Email sent:", emailResponse);

    // Update invitation with sent timestamp
    await supabase
      .from("invitations")
      .update({ 
        sent_at: new Date().toISOString(),
        status: "sent" 
      })
      .eq("id", invitation.id);

    // Update application status to invited
    await supabase
      .from("applications")
      .update({ status: "invited" })
      .eq("id", applicationId);

    // Note: Token is intentionally NOT returned in response for security
    // Token is only sent via email to the candidate
    return new Response(
      JSON.stringify({ 
        success: true, 
        invitationId: invitation.id,
        expiresAt: expiresAt.toISOString()
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );

  } catch (error: any) {
    console.error("Error in send-invitation:", error);
    return new Response(
      JSON.stringify({ error: "Failed to send invitation" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});

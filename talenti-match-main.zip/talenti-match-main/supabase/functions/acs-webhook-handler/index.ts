import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "node:crypto";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ACS Event Types
type AcsEventType = 
  | 'Microsoft.Communication.CallStarted'
  | 'Microsoft.Communication.CallEnded'
  | 'Microsoft.Communication.ParticipantAdded'
  | 'Microsoft.Communication.ParticipantRemoved'
  | 'Microsoft.Communication.RecordingFileStatusUpdated'
  | 'Microsoft.Communication.PlayCompleted'
  | 'Microsoft.Communication.PlayFailed'
  | 'Microsoft.Communication.RecognizeCompleted'
  | 'Microsoft.Communication.RecognizeFailed'
  | 'Microsoft.EventGrid.SubscriptionValidationEvent';

interface AcsEvent {
  id: string;
  topic: string;
  subject: string;
  data: Record<string, unknown>;
  eventType: AcsEventType;
  eventTime: string;
  metadataVersion?: string;
  dataVersion?: string;
}

// Valid event types for validation
const VALID_EVENT_TYPES = new Set<string>([
  'Microsoft.Communication.CallStarted',
  'Microsoft.Communication.CallEnded',
  'Microsoft.Communication.ParticipantAdded',
  'Microsoft.Communication.ParticipantRemoved',
  'Microsoft.Communication.RecordingFileStatusUpdated',
  'Microsoft.Communication.PlayCompleted',
  'Microsoft.Communication.PlayFailed',
  'Microsoft.Communication.RecognizeCompleted',
  'Microsoft.Communication.RecognizeFailed',
  'Microsoft.EventGrid.SubscriptionValidationEvent',
]);

// Verify Azure Event Grid webhook signature
function verifyEventGridSignature(
  body: string,
  signature: string,
  secret: string
): boolean {
  try {
    // Azure Event Grid uses HMAC-SHA256 signature
    const hash = createHmac('sha256', secret)
      .update(body)
      .digest('base64');
    
    // Constant-time comparison to prevent timing attacks
    if (hash.length !== signature.length) {
      return false;
    }
    
    let result = 0;
    for (let i = 0; i < hash.length; i++) {
      result |= hash.charCodeAt(i) ^ signature.charCodeAt(i);
    }
    return result === 0;
  } catch (error) {
    console.error('Signature verification error:', error);
    return false;
  }
}

// Validate UUID format for correlationId and serverCallId
function isValidUUID(str: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(str);
}

// Validate event structure
function validateEvent(event: unknown): event is AcsEvent {
  if (!event || typeof event !== 'object') {
    return false;
  }
  
  const e = event as Record<string, unknown>;
  
  // Required fields
  if (typeof e.id !== 'string' || e.id.length === 0 || e.id.length > 100) {
    return false;
  }
  if (typeof e.eventType !== 'string' || !VALID_EVENT_TYPES.has(e.eventType)) {
    return false;
  }
  if (typeof e.eventTime !== 'string') {
    return false;
  }
  if (!e.data || typeof e.data !== 'object') {
    return false;
  }
  
  return true;
}

// Validate and sanitize correlationId
function validateCorrelationId(data: Record<string, unknown>): string | null {
  const correlationId = data.correlationId;
  if (typeof correlationId !== 'string') {
    return null;
  }
  // Check UUID format to prevent injection
  if (!isValidUUID(correlationId)) {
    console.warn(`Invalid correlationId format: ${correlationId.substring(0, 50)}`);
    return null;
  }
  return correlationId;
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  // Only accept POST requests
  if (req.method !== 'POST') {
    console.warn(`Rejected non-POST request: ${req.method}`);
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    // Get raw body for signature verification
    const rawBody = await req.text();
    
    // Check content length to prevent DoS
    if (rawBody.length > 1024 * 1024) { // 1MB limit
      console.warn('Request body too large');
      return new Response(
        JSON.stringify({ error: 'Payload too large' }),
        { status: 413, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const webhookSecret = Deno.env.get('ACS_WEBHOOK_SECRET');
    
    // For Event Grid subscription validation, we need to check the event type first
    // Azure sends validation events without signature during initial setup
    let events: unknown[];
    try {
      events = JSON.parse(rawBody);
    } catch {
      console.error('Invalid JSON in request body');
      return new Response(
        JSON.stringify({ error: 'Invalid JSON' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!Array.isArray(events)) {
      console.error('Request body is not an array');
      return new Response(
        JSON.stringify({ error: 'Invalid request format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check for subscription validation event (sent without signature during setup)
    const isValidationRequest = events.length === 1 && 
      typeof events[0] === 'object' && 
      events[0] !== null &&
      (events[0] as Record<string, unknown>).eventType === 'Microsoft.EventGrid.SubscriptionValidationEvent';

    // Verify signature for non-validation requests
    if (!isValidationRequest) {
      // Get signature from Azure Event Grid header
      const signature = req.headers.get('aeg-signature') || req.headers.get('x-aeg-signature');
      
      if (!webhookSecret) {
        console.error('ACS_WEBHOOK_SECRET not configured');
        return new Response(
          JSON.stringify({ error: 'Webhook not configured' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!signature) {
        console.warn('Missing webhook signature');
        return new Response(
          JSON.stringify({ error: 'Missing signature' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!verifyEventGridSignature(rawBody, signature, webhookSecret)) {
        console.warn('Invalid webhook signature');
        return new Response(
          JSON.stringify({ error: 'Invalid signature' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const supabase = createClient(supabaseUrl, supabaseServiceKey) as any;

    console.log(`Received ${events.length} ACS event(s)`);

    for (const event of events) {
      // Validate event structure
      if (!validateEvent(event)) {
        console.warn('Invalid event structure, skipping:', JSON.stringify(event).substring(0, 200));
        continue;
      }

      console.log(`Processing event: ${event.eventType}`, JSON.stringify(event.data, null, 2));

      switch (event.eventType) {
        // Event Grid subscription validation
        case 'Microsoft.EventGrid.SubscriptionValidationEvent': {
          const validationCode = event.data.validationCode as string;
          if (typeof validationCode !== 'string' || validationCode.length === 0 || validationCode.length > 100) {
            console.error('Invalid validation code');
            return new Response(
              JSON.stringify({ error: 'Invalid validation code' }),
              { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
          }
          console.log('Subscription validation request received');
          return new Response(
            JSON.stringify({ validationResponse: validationCode }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Call started
        case 'Microsoft.Communication.CallStarted': {
          const serverCallId = event.data.serverCallId as string;
          const correlationId = validateCorrelationId(event.data);
          
          if (!correlationId) {
            console.warn('Invalid or missing correlationId for CallStarted event');
            continue;
          }
          
          console.log(`Call started: ${serverCallId}`);
          
          // Update interview status if we can map the call
          await updateInterviewFromCall(supabase, correlationId, {
            status: 'in_progress',
            started_at: new Date().toISOString(),
            metadata: { serverCallId, correlationId }
          });
          break;
        }

        // Call ended
        case 'Microsoft.Communication.CallEnded': {
          const serverCallId = event.data.serverCallId as string;
          const correlationId = validateCorrelationId(event.data);
          
          if (!correlationId) {
            console.warn('Invalid or missing correlationId for CallEnded event');
            continue;
          }
          
          console.log(`Call ended: ${serverCallId}`);
          
          await updateInterviewFromCall(supabase, correlationId, {
            status: 'completed',
            ended_at: new Date().toISOString()
          });
          break;
        }

        // Participant events
        case 'Microsoft.Communication.ParticipantAdded': {
          const participant = event.data.participant as { identifier: { rawId: string }; isMuted: boolean };
          const serverCallId = event.data.serverCallId as string;
          
          if (participant?.identifier?.rawId) {
            console.log(`Participant joined: ${participant.identifier.rawId.substring(0, 50)} to call ${serverCallId}`);
          }
          break;
        }

        case 'Microsoft.Communication.ParticipantRemoved': {
          const participant = event.data.participant as { identifier: { rawId: string } };
          const serverCallId = event.data.serverCallId as string;
          
          if (participant?.identifier?.rawId) {
            console.log(`Participant left: ${participant.identifier.rawId.substring(0, 50)} from call ${serverCallId}`);
          }
          break;
        }

        // Recording events
        case 'Microsoft.Communication.RecordingFileStatusUpdated': {
          const recordingStorageInfo = event.data.recordingStorageInfo as { 
            recordingChunks: Array<{ 
              documentId: string; 
              contentLocation: string;
              deleteLocation: string;
            }>;
          };
          const recordingDurationMs = event.data.recordingDurationMs as number;
          const sessionEndReason = event.data.sessionEndReason as string;
          
          console.log('Recording file ready:', {
            chunks: recordingStorageInfo?.recordingChunks?.length || 0,
            duration: recordingDurationMs,
            reason: sessionEndReason
          });
          
          // Store recording metadata - actual file download handled by Python service
          if (recordingStorageInfo?.recordingChunks) {
            for (const chunk of recordingStorageInfo.recordingChunks) {
              console.log(`Recording chunk: ${chunk.documentId}, location: ${chunk.contentLocation?.substring(0, 100)}`);
            }
          }
          break;
        }

        // Play/Recognize events (for IVR/bot scenarios)
        case 'Microsoft.Communication.PlayCompleted':
        case 'Microsoft.Communication.PlayFailed':
        case 'Microsoft.Communication.RecognizeCompleted':
        case 'Microsoft.Communication.RecognizeFailed': {
          const resultInformation = event.data.resultInformation as { code: number; subCode: number; message: string };
          
          console.log(`${event.eventType}:`, resultInformation);
          break;
        }

        default:
          console.log(`Unhandled event type: ${event.eventType}`);
      }
    }

    return new Response(
      JSON.stringify({ success: true, processed: events.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in acs-webhook-handler:', error);
    return new Response(
      JSON.stringify({ error: 'An error occurred processing your request' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function updateInterviewFromCall(
  supabase: any,
  correlationId: string,
  updates: Record<string, unknown>
) {
  try {
    // Find interview by correlation ID stored in metadata
    const { data: interviews, error: fetchError } = await supabase
      .from('interviews')
      .select('id, metadata')
      .filter('metadata->correlationId', 'eq', correlationId)
      .limit(1);

    if (fetchError) {
      console.error('Error fetching interview:', fetchError);
      return;
    }

    if (!interviews || interviews.length === 0) {
      console.log(`No interview found for correlationId: ${correlationId}`);
      return;
    }

    const interview = interviews[0];
    
    // Merge metadata updates
    const existingMetadata = (interview.metadata || {}) as Record<string, unknown>;
    const updateMetadata = (updates.metadata || {}) as Record<string, unknown>;
    const newMetadata = {
      ...existingMetadata,
      ...updateMetadata,
      lastEventAt: new Date().toISOString()
    };

    const { error: updateError } = await supabase
      .from('interviews')
      .update({
        ...updates,
        metadata: newMetadata,
        updated_at: new Date().toISOString()
      })
      .eq('id', interview.id);

    if (updateError) {
      console.error('Error updating interview:', updateError);
    } else {
      console.log(`Updated interview ${interview.id}`);
    }
  } catch (error) {
    console.error('Error in updateInterviewFromCall:', error);
  }
}

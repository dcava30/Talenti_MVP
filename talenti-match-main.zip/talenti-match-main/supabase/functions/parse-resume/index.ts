import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple in-memory rate limiter
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = { windowMs: 60000, maxRequests: 5 }; // 5 requests per minute (file processing is expensive)

function checkRateLimit(identifier: string): { isLimited: boolean; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || entry.resetAt <= now) {
    rateLimitStore.set(identifier, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return { isLimited: false, resetAt: now + RATE_LIMIT.windowMs };
  }
  
  if (entry.count >= RATE_LIMIT.maxRequests) {
    return { isLimited: true, resetAt: entry.resetAt };
  }
  
  entry.count++;
  return { isLimited: false, resetAt: entry.resetAt };
}

function getClientIP(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() 
    || req.headers.get('x-real-ip') 
    || req.headers.get('cf-connecting-ip') 
    || 'unknown';
}

interface ParsedResume {
  personal: {
    first_name?: string;
    last_name?: string;
    email?: string;
    phone?: string;
    linkedin_url?: string;
    portfolio_url?: string;
    location?: {
      suburb?: string;
      state?: string;
      postcode?: string;
      country?: string;
    };
  };
  employment: Array<{
    job_title: string;
    company_name: string;
    start_date: string;
    end_date?: string;
    is_current: boolean;
    description: string;
  }>;
  education: Array<{
    institution: string;
    degree: string;
    field_of_study?: string;
    start_date?: string;
    end_date?: string;
    is_current: boolean;
  }>;
  skills: Array<{
    skill_name: string;
    skill_type: "hard" | "soft";
  }>;
  summary?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check rate limit by IP first (prevent brute force)
    const clientIP = getClientIP(req);
    const rateLimitResult = checkRateLimit(`ip:${clientIP}`);
    
    if (rateLimitResult.isLimited) {
      const retryAfter = Math.ceil((rateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ success: false, error: "Too many requests. Please try again later.", retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": retryAfter.toString()
          } 
        }
      );
    }

    // Verify authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ success: false, error: 'Unauthorized - authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the JWT and get user claims
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error('Auth verification failed:', claimsError);
      return new Response(
        JSON.stringify({ success: false, error: 'Unauthorized - invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const authenticatedUserId = claimsData.claims.sub as string;
    console.log(`Parse Resume - Authenticated user: ${authenticatedUserId}`);

    // Add per-user rate limiting
    const userRateLimitResult = checkRateLimit(`user:${authenticatedUserId}`);
    if (userRateLimitResult.isLimited) {
      const retryAfter = Math.ceil((userRateLimitResult.resetAt - Date.now()) / 1000);
      return new Response(
        JSON.stringify({ success: false, error: "Too many requests for your account. Please try again later.", retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": retryAfter.toString()
          } 
        }
      );
    }

    const { filePath, userId } = await req.json();

    if (!filePath || !userId) {
      return new Response(
        JSON.stringify({ success: false, error: "Missing filePath or userId" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify user owns the CV being parsed (must match authenticated user)
    if (authenticatedUserId !== userId) {
      console.warn(`User ${authenticatedUserId} attempted to parse CV for ${userId}`);
      return new Response(
        JSON.stringify({ success: false, error: "Unauthorized - can only parse own CV" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate filePath format and ownership
    const expectedPrefix = `${userId}/`;
    if (!filePath.startsWith(expectedPrefix)) {
      return new Response(
        JSON.stringify({ success: false, error: "Invalid file path format" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Sanitize path to prevent traversal attacks
    const sanitizedPath = filePath.replace(/\.\./g, '').replace(/\/\//g, '/');
    if (sanitizedPath !== filePath) {
      return new Response(
        JSON.stringify({ success: false, error: "Invalid file path - path traversal detected" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify file exists in candidate_profiles for this user
    const { data: profile } = await userClient
      .from('candidate_profiles')
      .select('cv_file_path')
      .eq('user_id', userId)
      .maybeSingle();

    if (!profile || profile.cv_file_path !== filePath) {
      return new Response(
        JSON.stringify({ success: false, error: "File not found in profile" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY not configured");
      return new Response(
        JSON.stringify({ success: false, error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create Supabase client with service role for file download (after all validation passed)
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log("Downloading resume from storage:", sanitizedPath);

    // Download the file from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("candidate-cvs")
      .download(sanitizedPath);

    if (downloadError || !fileData) {
      console.error("Failed to download file:", downloadError);
      return new Response(
        JSON.stringify({ success: false, error: "Failed to download resume file" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Convert PDF to base64 for AI processing
    const arrayBuffer = await fileData.arrayBuffer();
    const base64Content = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));

    console.log("Calling AI to parse resume...");

    // Use Lovable AI to extract structured data
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are a resume parsing expert. Extract structured information from the resume provided. 
Be thorough and accurate. For dates, use YYYY-MM-DD format. If a date is not available, omit the field.
For skills, categorize them as "hard" (technical skills, tools, languages) or "soft" (communication, leadership, etc).
Always return valid JSON matching the exact schema requested.`,
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Parse this resume and extract structured data. Return a JSON object with this exact structure:

{
  "personal": {
    "first_name": "string or null",
    "last_name": "string or null", 
    "email": "string or null",
    "phone": "string or null",
    "linkedin_url": "string or null",
    "portfolio_url": "string or null",
    "location": {
      "suburb": "string or null",
      "state": "string or null (e.g., NSW, VIC, QLD)",
      "postcode": "string or null",
      "country": "string, default to Australia"
    }
  },
  "employment": [
    {
      "job_title": "string",
      "company_name": "string",
      "start_date": "YYYY-MM-DD",
      "end_date": "YYYY-MM-DD or null if current",
      "is_current": boolean,
      "description": "string, brief description of responsibilities"
    }
  ],
  "education": [
    {
      "institution": "string",
      "degree": "string",
      "field_of_study": "string or null",
      "start_date": "YYYY-MM-DD or null",
      "end_date": "YYYY-MM-DD or null",
      "is_current": boolean
    }
  ],
  "skills": [
    {
      "skill_name": "string",
      "skill_type": "hard" or "soft"
    }
  ],
  "summary": "Brief professional summary extracted from resume"
}

Return ONLY the JSON object, no markdown or explanation.`,
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:application/pdf;base64,${base64Content}`,
                },
              },
            ],
          },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "parse_resume",
              description: "Parse resume and return structured data",
              parameters: {
                type: "object",
                properties: {
                  personal: {
                    type: "object",
                    properties: {
                      first_name: { type: "string" },
                      last_name: { type: "string" },
                      email: { type: "string" },
                      phone: { type: "string" },
                      linkedin_url: { type: "string" },
                      portfolio_url: { type: "string" },
                      location: {
                        type: "object",
                        properties: {
                          suburb: { type: "string" },
                          state: { type: "string" },
                          postcode: { type: "string" },
                          country: { type: "string" },
                        },
                      },
                    },
                  },
                  employment: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        job_title: { type: "string" },
                        company_name: { type: "string" },
                        start_date: { type: "string" },
                        end_date: { type: "string" },
                        is_current: { type: "boolean" },
                        description: { type: "string" },
                      },
                      required: ["job_title", "company_name", "start_date", "is_current"],
                    },
                  },
                  education: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        institution: { type: "string" },
                        degree: { type: "string" },
                        field_of_study: { type: "string" },
                        start_date: { type: "string" },
                        end_date: { type: "string" },
                        is_current: { type: "boolean" },
                      },
                      required: ["institution", "degree"],
                    },
                  },
                  skills: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        skill_name: { type: "string" },
                        skill_type: { type: "string", enum: ["hard", "soft"] },
                      },
                      required: ["skill_name", "skill_type"],
                    },
                  },
                  summary: { type: "string" },
                },
                required: ["personal", "employment", "education", "skills"],
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "parse_resume" } },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI API error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ success: false, error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ success: false, error: "AI credits depleted. Please add credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ success: false, error: "Failed to parse resume with AI" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiResponse = await response.json();
    console.log("AI Response received");

    // Extract tool call result
    const toolCall = aiResponse.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall || toolCall.function.name !== "parse_resume") {
      console.error("No valid tool call in response");
      return new Response(
        JSON.stringify({ success: false, error: "Failed to extract resume data" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const parsedData: ParsedResume = JSON.parse(toolCall.function.arguments);
    console.log("Parsed resume data:", JSON.stringify(parsedData, null, 2));

    return new Response(
      JSON.stringify({ success: true, data: parsedData }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error parsing resume:", error);
    return new Response(
      JSON.stringify({ success: false, error: "An error occurred processing your request" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

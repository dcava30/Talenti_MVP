import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Simple in-memory rate limiter
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = { windowMs: 300000, maxRequests: 10 }; // 10 requests per 5 minutes

function checkRateLimit(identifier: string): { isLimited: boolean; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || entry.resetAt <= now) {
    rateLimitStore.set(identifier, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return { isLimited: false, resetAt: now + RATE_LIMIT.windowMs };
  }
  
  if (entry.count >= RATE_LIMIT.maxRequests) {
    return { isLimited: true, resetAt: entry.resetAt };
  }
  
  entry.count++;
  return { isLimited: false, resetAt: entry.resetAt };
}

function getClientIP(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() 
    || req.headers.get('x-real-ip') 
    || req.headers.get('cf-connecting-ip') 
    || 'unknown';
}

interface TranscriptSegment {
  speaker: string;
  content: string;
  start_time_ms: number;
}

interface ScoringDimension {
  dimension: string;
  weight: number;
  label: string;
}

interface ScoringRequest {
  interviewId: string;
  transcripts: TranscriptSegment[];
  jobTitle: string;
  jobDescription?: string;
  requirements?: {
    skills?: string[];
    experience?: string[];
    qualifications?: string[];
    responsibilities?: string[];
  };
  orgValues?: string[];
  scoringRubric?: Record<string, ScoringDimension>;
}

const DEFAULT_DIMENSIONS = [
  { dimension: "vocabulary", weight: 0.1, label: "Vocabulary" },
  { dimension: "domain_knowledge", weight: 0.15, label: "Domain Knowledge" },
  { dimension: "technical_skills", weight: 0.2, label: "Technical Skills" },
  { dimension: "experience_depth", weight: 0.1, label: "Experience Depth" },
  { dimension: "communication", weight: 0.15, label: "Communication" },
  { dimension: "culture_fit", weight: 0.1, label: "Culture Fit" },
  { dimension: "motivation", weight: 0.1, label: "Motivation" },
  { dimension: "confidence", weight: 0.1, label: "Confidence" },
];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check rate limit by IP
    const clientIP = getClientIP(req);
    const rateLimitResult = checkRateLimit(`ip:${clientIP}`);
    
    if (rateLimitResult.isLimited) {
      const retryAfter = Math.ceil((rateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: 'Too many requests. Please try again later.', retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Retry-After': retryAfter.toString()
          } 
        }
      );
    }
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const { 
      interviewId, 
      transcripts, 
      jobTitle, 
      jobDescription, 
      requirements, 
      orgValues,
      scoringRubric,
    }: ScoringRequest = await req.json();

    console.log("Scoring interview:", interviewId);
    console.log("Transcript segments:", transcripts.length);
    console.log("Using custom rubric:", !!scoringRubric);

    // Determine which dimensions and weights to use
    const dimensions = scoringRubric 
      ? Object.entries(scoringRubric).map(([dim, config]) => ({
          dimension: dim,
          weight: config.weight,
          label: config.label,
        }))
      : DEFAULT_DIMENSIONS;

    // Format transcript for analysis
    const formattedTranscript = transcripts
      .sort((a, b) => a.start_time_ms - b.start_time_ms)
      .map((seg) => {
        const timeMin = Math.floor(seg.start_time_ms / 60000);
        const timeSec = Math.floor((seg.start_time_ms % 60000) / 1000);
        const timeStr = `${timeMin}:${timeSec.toString().padStart(2, '0')}`;
        return `[${timeStr}] ${seg.speaker.toUpperCase()}: ${seg.content}`;
      })
      .join('\n\n');

    // Build dynamic scoring prompt with org-specific weights
    const dimensionList = dimensions
      .map(d => `- **${d.label}** (${d.dimension}): Weight ${Math.round(d.weight * 100)}%`)
      .join('\n');

    const SCORING_PROMPT = `You are an expert AI interview scorer for Talenti, an AI-powered recruitment platform. Your task is to analyze interview transcripts and provide objective, evidence-based scoring.

## Scoring Dimensions (0-10 scale, with organization-specific weights)
${dimensionList}

## Scoring Instructions
1. Analyze the full transcript carefully
2. Score each dimension from 0-10 with 0.5 precision
3. Apply the specified weights when calculating the overall score
4. Provide specific evidence with time-stamped quotes from the transcript
5. Write a 3-5 paragraph narrative summary
6. Generate constructive feedback for the candidate
7. Assess anti-cheat risk level based on response patterns

## Important Guidelines
- Be objective and fair - base scores on demonstrated evidence only
- Quote specific responses as evidence
- Consider the job requirements when scoring
- Flag any concerning patterns (long pauses, inconsistent responses)
${orgValues?.length ? `
## Organization Values to Evaluate Against
${orgValues.map((v, i) => `${i + 1}. ${v}`).join('\n')}
When scoring culture_fit, specifically evaluate alignment with these values.` : ''}`;

    const userPrompt = `## Job Information
**Position:** ${jobTitle}
${jobDescription ? `**Description:** ${jobDescription}` : ''}
${requirements?.skills?.length ? `**Required Skills:** ${requirements.skills.join(', ')}` : ''}
${requirements?.experience?.length ? `**Experience Requirements:** ${requirements.experience.join('; ')}` : ''}

## Interview Transcript
${formattedTranscript}

## Your Task
Analyze this interview and provide:
1. Scores for each dimension (${dimensions.map(d => d.dimension).join(', ')})
2. Evidence and quotes for each score
3. A narrative summary (3-5 paragraphs)
4. Constructive feedback for the candidate
5. Anti-cheat risk assessment (low/medium/high)

Use the specified weights: ${dimensions.map(d => `${d.dimension}=${Math.round(d.weight * 100)}%`).join(', ')}

Respond using the score_interview function.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: SCORING_PROMPT },
          { role: 'user', content: userPrompt }
        ],
        tools: [
          {
            type: 'function',
            function: {
              name: 'score_interview',
              description: 'Submit the complete interview scoring analysis',
              parameters: {
                type: 'object',
                properties: {
                  dimensions: {
                    type: 'array',
                    description: 'Scores for each evaluation dimension',
                    items: {
                      type: 'object',
                      properties: {
                        dimension: { 
                          type: 'string',
                          enum: dimensions.map(d => d.dimension)
                        },
                        score: { type: 'number', minimum: 0, maximum: 10 },
                        weight: { type: 'number', minimum: 0, maximum: 1 },
                        evidence: { type: 'string', description: 'Explanation for the score' },
                        cited_quotes: { 
                          type: 'array', 
                          items: { type: 'string' },
                          description: 'Direct quotes from transcript supporting the score'
                        }
                      },
                      required: ['dimension', 'score', 'weight', 'evidence', 'cited_quotes']
                    }
                  },
                  overall_score: { 
                    type: 'number', 
                    minimum: 0, 
                    maximum: 100,
                    description: 'Weighted overall percentage score'
                  },
                  narrative_summary: { 
                    type: 'string',
                    description: '3-5 paragraph professional summary of the candidate'
                  },
                  candidate_feedback: { 
                    type: 'string',
                    description: 'Constructive feedback for the candidate (what they did well and areas to improve)'
                  },
                  anti_cheat_risk_level: { 
                    type: 'string',
                    enum: ['low', 'medium', 'high'],
                    description: 'Assessment of potential cheating indicators'
                  },
                  anti_cheat_notes: {
                    type: 'string',
                    description: 'Notes on any concerning patterns observed'
                  }
                },
                required: ['dimensions', 'overall_score', 'narrative_summary', 'candidate_feedback', 'anti_cheat_risk_level']
              }
            }
          }
        ],
        tool_choice: { type: 'function', function: { name: 'score_interview' } },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded, please try again later' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'Payment required, please add credits' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response received");

    // Extract function call arguments
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall || toolCall.function.name !== 'score_interview') {
      console.error("Unexpected response format:", JSON.stringify(data));
      throw new Error('Invalid response format from AI');
    }

    const scoringResult = JSON.parse(toolCall.function.arguments);
    console.log("Scoring complete. Overall score:", scoringResult.overall_score);

    return new Response(JSON.stringify({
      success: true,
      interviewId,
      ...scoringResult
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Scoring error:', error);
    return new Response(JSON.stringify({ 
      error: 'An error occurred processing your request' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
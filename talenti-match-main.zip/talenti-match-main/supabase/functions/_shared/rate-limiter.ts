/**
 * Simple in-memory rate limiter for edge functions
 * Note: In a production multi-instance deployment, consider using Redis or a database
 * This implementation works well for single-instance deployments
 */

interface RateLimitEntry {
  count: number;
  resetAt: number;
}

interface RateLimitConfig {
  windowMs: number;     // Time window in milliseconds
  maxRequests: number;  // Maximum requests allowed in the window
}

// In-memory store for rate limiting (shared across requests in the same edge function instance)
const rateLimitStore = new Map<string, RateLimitEntry>();

// Clean up expired entries periodically
let lastCleanup = Date.now();
const CLEANUP_INTERVAL = 60000; // Clean up every minute

function cleanupExpiredEntries() {
  const now = Date.now();
  if (now - lastCleanup < CLEANUP_INTERVAL) return;
  
  lastCleanup = now;
  for (const [key, entry] of rateLimitStore.entries()) {
    if (entry.resetAt <= now) {
      rateLimitStore.delete(key);
    }
  }
}

/**
 * Check if a request should be rate limited
 * @param identifier - Unique identifier for rate limiting (userId, IP, etc.)
 * @param config - Rate limit configuration
 * @returns Object with isLimited boolean and remaining requests info
 */
export function checkRateLimit(
  identifier: string,
  config: RateLimitConfig
): { isLimited: boolean; remaining: number; resetAt: number } {
  cleanupExpiredEntries();
  
  const now = Date.now();
  const key = identifier;
  const entry = rateLimitStore.get(key);
  
  if (!entry || entry.resetAt <= now) {
    // First request in a new window
    const resetAt = now + config.windowMs;
    rateLimitStore.set(key, { count: 1, resetAt });
    return { isLimited: false, remaining: config.maxRequests - 1, resetAt };
  }
  
  if (entry.count >= config.maxRequests) {
    // Rate limit exceeded
    return { isLimited: true, remaining: 0, resetAt: entry.resetAt };
  }
  
  // Increment counter
  entry.count++;
  return { isLimited: false, remaining: config.maxRequests - entry.count, resetAt: entry.resetAt };
}

/**
 * Get client identifier from request (IP address or fallback)
 */
export function getClientIdentifier(req: Request): string {
  // Try various headers that might contain the client IP
  const forwarded = req.headers.get('x-forwarded-for');
  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }
  
  const realIp = req.headers.get('x-real-ip');
  if (realIp) {
    return realIp;
  }
  
  const cfConnecting = req.headers.get('cf-connecting-ip');
  if (cfConnecting) {
    return cfConnecting;
  }
  
  // Fallback to a generic identifier if no IP found
  return 'unknown-client';
}

/**
 * Create rate limit response with proper headers
 */
export function createRateLimitResponse(
  resetAt: number,
  corsHeaders: Record<string, string>
): Response {
  const retryAfter = Math.ceil((resetAt - Date.now()) / 1000);
  
  return new Response(
    JSON.stringify({ 
      error: 'Too many requests. Please try again later.',
      retryAfter 
    }),
    { 
      status: 429, 
      headers: { 
        ...corsHeaders, 
        'Content-Type': 'application/json',
        'Retry-After': retryAfter.toString(),
        'X-RateLimit-Reset': new Date(resetAt).toISOString()
      } 
    }
  );
}

// Pre-configured rate limits for different use cases
export const RATE_LIMITS = {
  // Token generation - strict limits
  TOKEN_GENERATION: { windowMs: 60000, maxRequests: 10 },  // 10 per minute
  
  // AI-heavy operations - moderate limits
  AI_OPERATION: { windowMs: 60000, maxRequests: 20 },      // 20 per minute
  
  // Standard API calls - relaxed limits
  STANDARD_API: { windowMs: 60000, maxRequests: 60 },      // 60 per minute
  
  // Resume parsing - moderate (AI + file processing)
  RESUME_PARSE: { windowMs: 60000, maxRequests: 5 },       // 5 per minute
  
  // Interview scoring - low frequency expected
  INTERVIEW_SCORE: { windowMs: 300000, maxRequests: 10 },  // 10 per 5 minutes
  
  // Shortlist generation - low frequency
  SHORTLIST: { windowMs: 300000, maxRequests: 10 },        // 10 per 5 minutes
};

import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Simple in-memory rate limiter
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = { windowMs: 300000, maxRequests: 10 }; // 10 requests per 5 minutes

function checkRateLimit(identifier: string): { isLimited: boolean; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || entry.resetAt <= now) {
    rateLimitStore.set(identifier, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return { isLimited: false, resetAt: now + RATE_LIMIT.windowMs };
  }
  
  if (entry.count >= RATE_LIMIT.maxRequests) {
    return { isLimited: true, resetAt: entry.resetAt };
  }
  
  entry.count++;
  return { isLimited: false, resetAt: entry.resetAt };
}

function getClientIP(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() 
    || req.headers.get('x-real-ip') 
    || req.headers.get('cf-connecting-ip') 
    || 'unknown';
}

interface CandidateMatch {
  applicationId: string;
  candidateId: string;
  matchScore: number;
  matchReasons: string[];
  skills: string[];
  experience: string;
  availability: string;
  workMode: string;
  location: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check rate limit by IP first
    const clientIP = getClientIP(req);
    const rateLimitResult = checkRateLimit(`ip:${clientIP}`);
    
    if (rateLimitResult.isLimited) {
      const retryAfter = Math.ceil((rateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: 'Too many requests. Please try again later.', retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Retry-After': retryAfter.toString()
          } 
        }
      );
    }
    // Verify user authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY')!;

    // Create auth client to verify user
    const authClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the JWT and get user
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await authClient.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error('Auth verification failed:', claimsError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userId = claimsData.claims.sub as string;
    console.log(`Authenticated user: ${userId}`);

    const { roleId } = await req.json();

    if (!roleId) {
      return new Response(
        JSON.stringify({ error: 'roleId is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify user has access to this role's organization using RLS-enforced query
    const { data: role, error: roleError } = await authClient
      .from('job_roles')
      .select('id, title, department, location, work_type, employment_type, industry, description, requirements, organisation_id')
      .eq('id', roleId)
      .single();

    if (roleError || !role) {
      console.error('Role access denied or not found:', roleError);
      return new Response(
        JSON.stringify({ error: 'Role not found or access denied' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify user belongs to the organization
    const { data: orgUser, error: orgError } = await authClient
      .from('org_users')
      .select('role')
      .eq('organisation_id', role.organisation_id)
      .eq('user_id', userId)
      .maybeSingle();

    if (orgError || !orgUser) {
      console.error('User not in organization:', orgError);
      return new Response(
        JSON.stringify({ error: 'Access denied - not a member of this organization' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`User ${userId} authorized for org role: ${orgUser.role}`);

    // Now use service client for data access (authorized user confirmed)
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch applications for this role with candidate profiles and skills
    const { data: applications, error: appsError } = await supabase
      .from('applications')
      .select('id, candidate_id, status, match_score')
      .eq('job_role_id', roleId);

    if (appsError) {
      console.error('Applications fetch error:', appsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch applications' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!applications || applications.length === 0) {
      return new Response(
        JSON.stringify({ matches: [], message: 'No candidates to match' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch candidate profiles for all applications (only non-PII fields for matching)
    const candidateIds = applications.map(a => a.candidate_id);
    
    const { data: profiles, error: profilesError } = await supabase
      .from('candidate_profiles')
      .select('user_id, availability, work_mode, state, work_rights')
      .in('user_id', candidateIds);

    if (profilesError) {
      console.error('Profiles fetch error:', profilesError);
    }

    // Fetch skills for all candidates
    const { data: allSkills, error: skillsError } = await supabase
      .from('candidate_skills')
      .select('user_id, skill_name, skill_type, proficiency_level')
      .in('user_id', candidateIds);

    if (skillsError) {
      console.error('Skills fetch error:', skillsError);
    }

    // Fetch employment history for experience context (anonymized)
    const { data: employment, error: empError } = await supabase
      .from('employment_history')
      .select('user_id, job_title, description, start_date, end_date, is_current')
      .in('user_id', candidateIds)
      .order('start_date', { ascending: false });

    if (empError) {
      console.error('Employment fetch error:', empError);
    }

    // Build candidate summaries for AI matching (anonymized - no PII)
    const candidateSummaries = applications.map(app => {
      const profile = profiles?.find(p => p.user_id === app.candidate_id);
      const skills = allSkills?.filter(s => s.user_id === app.candidate_id) || [];
      const jobs = employment?.filter(e => e.user_id === app.candidate_id) || [];

      const skillList = skills.map(s => s.skill_name).join(', ');
      // Anonymize company names for AI matching
      const experienceSummary = jobs.slice(0, 3).map(j => 
        `${j.job_title}${j.description ? ': ' + j.description.slice(0, 100) : ''}`
      ).join('; ');

      return {
        applicationId: app.candidate_id,
        candidateId: app.candidate_id,
        skills: skillList || 'Not specified',
        experience: experienceSummary || 'No experience listed',
        availability: profile?.availability || 'Not specified',
        workMode: profile?.work_mode || 'Not specified',
        location: profile?.state || 'Not specified',
        workRights: profile?.work_rights || 'Not specified',
      };
    });

    // Build the matching prompt
    const roleContext = `
Role Title: ${role.title}
Department: ${role.department || 'Not specified'}
Location: ${role.location || 'Not specified'}
Work Type: ${role.work_type || 'Not specified'}
Employment Type: ${role.employment_type || 'Not specified'}
Industry: ${role.industry || 'Not specified'}
Description: ${role.description || 'Not provided'}
Requirements: ${JSON.stringify(role.requirements) || 'Not specified'}
`;

    const candidatesContext = candidateSummaries.map((c, i) => `
Candidate ${i + 1} (ID: ${c.applicationId}):
- Skills: ${c.skills}
- Experience: ${c.experience}
- Availability: ${c.availability}
- Work Mode Preference: ${c.workMode}
- Location: ${c.location}
- Work Rights: ${c.workRights}
`).join('\n');

    console.log('Calling AI for semantic matching...');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are an AI recruitment assistant that evaluates candidate-job fit using semantic matching. 
Analyze each candidate against the job requirements and provide match scores (0-100) with reasoning.
Consider: skills alignment, experience relevance, availability match, work mode compatibility, and location fit.
Be objective and focus on qualifications, not personal attributes.`
          },
          {
            role: 'user',
            content: `Evaluate these candidates for the following role and rank them by fit.

${roleContext}

CANDIDATES:
${candidatesContext}

For each candidate, provide a match score (0-100) and 2-3 key reasons for the score.
Focus on skills, experience, and job requirements alignment.`
          }
        ],
        tools: [
          {
            type: 'function',
            function: {
              name: 'rank_candidates',
              description: 'Rank candidates by their match score for the job role',
              parameters: {
                type: 'object',
                properties: {
                  rankings: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        candidateId: { type: 'string', description: 'The candidate ID' },
                        matchScore: { type: 'number', description: 'Match score from 0-100' },
                        matchReasons: { 
                          type: 'array', 
                          items: { type: 'string' },
                          description: '2-3 key reasons for the match score'
                        }
                      },
                      required: ['candidateId', 'matchScore', 'matchReasons']
                    }
                  }
                },
                required: ['rankings']
              }
            }
          }
        ],
        tool_choice: { type: 'function', function: { name: 'rank_candidates' } }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Usage limit reached. Please add credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: 'AI matching failed' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const aiResponse = await response.json();
    console.log('AI response received');

    // Parse the tool call response
    const toolCall = aiResponse.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      console.error('No tool call in response');
      return new Response(
        JSON.stringify({ error: 'Invalid AI response format' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const rankings = JSON.parse(toolCall.function.arguments);
    console.log('Parsed rankings:', rankings);

    // Update match scores in the database
    const updatePromises = rankings.rankings.map(async (ranking: any) => {
      const app = applications.find(a => a.candidate_id === ranking.candidateId);
      if (app) {
        await supabase
          .from('applications')
          .update({ match_score: ranking.matchScore })
          .eq('id', app.id);
      }
    });

    await Promise.all(updatePromises);

    // Build the final response with anonymized candidate data
    const matches: CandidateMatch[] = rankings.rankings.map((ranking: any) => {
      const app = applications.find(a => a.candidate_id === ranking.candidateId);
      const summary = candidateSummaries.find(c => c.candidateId === ranking.candidateId);
      
      return {
        applicationId: app?.id || '',
        candidateId: ranking.candidateId,
        matchScore: ranking.matchScore,
        matchReasons: ranking.matchReasons,
        skills: summary?.skills?.split(', ').slice(0, 5) || [],
        experience: summary?.experience || 'Not specified',
        availability: summary?.availability || 'Not specified',
        workMode: summary?.workMode || 'Not specified',
        location: summary?.location || 'Not specified',
      };
    }).sort((a: CandidateMatch, b: CandidateMatch) => b.matchScore - a.matchScore);

    return new Response(
      JSON.stringify({ matches, roleTitle: role.title }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in generate-shortlist:', error);
    return new Response(
      JSON.stringify({ error: 'An error occurred processing your request' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

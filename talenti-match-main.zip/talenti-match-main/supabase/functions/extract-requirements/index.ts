import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple in-memory rate limiter
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = { windowMs: 60000, maxRequests: 20 }; // 20 requests per minute

function checkRateLimit(identifier: string): { isLimited: boolean; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || entry.resetAt <= now) {
    rateLimitStore.set(identifier, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return { isLimited: false, resetAt: now + RATE_LIMIT.windowMs };
  }
  
  if (entry.count >= RATE_LIMIT.maxRequests) {
    return { isLimited: true, resetAt: entry.resetAt };
  }
  
  entry.count++;
  return { isLimited: false, resetAt: entry.resetAt };
}

function getClientIP(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() 
    || req.headers.get('x-real-ip') 
    || req.headers.get('cf-connecting-ip') 
    || 'unknown';
}

interface ExtractedRequirements {
  skills: string[];
  experience: string[];
  qualifications: string[];
  responsibilities: string[];
  interviewQuestions: string[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check rate limit by IP first (prevent brute force)
    const clientIP = getClientIP(req);
    const rateLimitResult = checkRateLimit(`ip:${clientIP}`);
    
    if (rateLimitResult.isLimited) {
      const retryAfter = Math.ceil((rateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: "Too many requests. Please try again later.", retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": retryAfter.toString()
          } 
        }
      );
    }

    // Verify authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized - authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the JWT is valid
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error('Auth verification failed:', claimsError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized - invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userId = claimsData.claims.sub as string;
    console.log(`Authenticated user ${userId} requesting requirement extraction`);

    // Add per-user rate limiting
    const userRateLimitResult = checkRateLimit(`user:${userId}`);
    if (userRateLimitResult.isLimited) {
      const retryAfter = Math.ceil((userRateLimitResult.resetAt - Date.now()) / 1000);
      return new Response(
        JSON.stringify({ error: "Too many requests for your account. Please try again later.", retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": retryAfter.toString()
          } 
        }
      );
    }
    const { jobDescription, jobTitle } = await req.json();
    
    if (!jobDescription) {
      throw new Error("Job description is required");
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Extracting requirements for:", jobTitle);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are an expert HR analyst. Extract structured requirements from job descriptions. Be precise and comprehensive.`
          },
          {
            role: "user",
            content: `Analyze this job description for "${jobTitle || 'the role'}" and extract key requirements:\n\n${jobDescription}`
          }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_job_requirements",
              description: "Extract structured requirements from a job description",
              parameters: {
                type: "object",
                properties: {
                  skills: {
                    type: "array",
                    items: { type: "string" },
                    description: "Technical and soft skills required (e.g., 'React', 'TypeScript', 'Team leadership')"
                  },
                  experience: {
                    type: "array",
                    items: { type: "string" },
                    description: "Experience requirements (e.g., '5+ years in frontend development')"
                  },
                  qualifications: {
                    type: "array",
                    items: { type: "string" },
                    description: "Educational or certification requirements"
                  },
                  responsibilities: {
                    type: "array",
                    items: { type: "string" },
                    description: "Key responsibilities of the role"
                  },
                  interviewQuestions: {
                    type: "array",
                    items: { type: "string" },
                    description: "5-7 suggested interview questions based on the role requirements"
                  }
                },
                required: ["skills", "experience", "qualifications", "responsibilities", "interviewQuestions"],
                additionalProperties: false
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "extract_job_requirements" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI usage limit reached. Please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response:", JSON.stringify(data));

    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      throw new Error("No tool call response from AI");
    }

    const requirements: ExtractedRequirements = JSON.parse(toolCall.function.arguments);
    
    console.log("Extracted requirements:", requirements);

    return new Response(JSON.stringify({ success: true, requirements }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("Error in extract-requirements:", error);
    return new Response(JSON.stringify({ error: "An error occurred processing your request" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

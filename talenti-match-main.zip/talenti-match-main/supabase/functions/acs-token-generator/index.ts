import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TokenRequest {
  scopes?: string[];
}

interface CommunicationIdentityToken {
  token: string;
  expiresOn: string;
  user: {
    communicationUserId: string;
  };
}

// Simple in-memory rate limiter
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = { windowMs: 60000, maxRequests: 10 }; // 10 requests per minute

function checkRateLimit(identifier: string): { isLimited: boolean; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || entry.resetAt <= now) {
    rateLimitStore.set(identifier, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return { isLimited: false, resetAt: now + RATE_LIMIT.windowMs };
  }
  
  if (entry.count >= RATE_LIMIT.maxRequests) {
    return { isLimited: true, resetAt: entry.resetAt };
  }
  
  entry.count++;
  return { isLimited: false, resetAt: entry.resetAt };
}

function getClientIP(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() 
    || req.headers.get('x-real-ip') 
    || req.headers.get('cf-connecting-ip') 
    || 'unknown';
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check rate limit by IP first (before auth)
    const clientIP = getClientIP(req);
    const rateLimitResult = checkRateLimit(`ip:${clientIP}`);
    
    if (rateLimitResult.isLimited) {
      const retryAfter = Math.ceil((rateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: 'Too many requests. Please try again later.', retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Retry-After': retryAfter.toString()
          } 
        }
      );
    }
    // Verify user authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the JWT and get user
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error('Auth verification failed:', claimsError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userId = claimsData.claims.sub as string;
    console.log(`Authenticated user: ${userId}`);

    const connectionString = Deno.env.get('ACS_CONNECTION_STRING');
    
    if (!connectionString) {
      console.error('ACS_CONNECTION_STRING not configured');
      return new Response(
        JSON.stringify({ error: 'Service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse connection string to extract endpoint and key
    const parsed = parseConnectionString(connectionString);
    if (!parsed) {
      console.error('Invalid ACS connection string format');
      return new Response(
        JSON.stringify({ error: 'Service configuration error' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { endpoint, accessKey } = parsed;
    
    // Parse request body - only accept scopes, userId comes from auth
    const { scopes = ['voip'] } = await req.json() as TokenRequest;
    
    console.log(`Generating ACS token for authenticated user: ${userId}, scopes: ${scopes.join(', ')}`);

    // Step 1: Create a communication identity
    const identityResponse = await createIdentity(endpoint, accessKey);
    
    if (!identityResponse.ok) {
      const errorText = await identityResponse.text();
      console.error('Failed to create identity:', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to create communication identity' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const identity = await identityResponse.json();
    const communicationUserId = identity.identity.id;
    
    console.log(`Created identity: ${communicationUserId}`);

    // Step 2: Generate access token for the identity
    const tokenResponse = await generateToken(endpoint, accessKey, communicationUserId, scopes);
    
    if (!tokenResponse.ok) {
      const errorText = await tokenResponse.text();
      console.error('Failed to generate token:', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to generate access token' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const tokenData = await tokenResponse.json();
    
    const result: CommunicationIdentityToken = {
      token: tokenData.accessToken.token,
      expiresOn: tokenData.accessToken.expiresOn,
      user: {
        communicationUserId
      }
    };

    console.log(`Token generated successfully, expires: ${result.expiresOn}`);

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in acs-token-generator:', error);
    return new Response(
      JSON.stringify({ error: 'An error occurred processing your request' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function parseConnectionString(connectionString: string): { endpoint: string; accessKey: string } | null {
  try {
    const parts = connectionString.split(';');
    let endpoint = '';
    let accessKey = '';

    for (const part of parts) {
      if (part.startsWith('endpoint=')) {
        endpoint = part.substring('endpoint='.length);
      } else if (part.startsWith('accesskey=')) {
        accessKey = part.substring('accesskey='.length);
      }
    }

    if (!endpoint || !accessKey) {
      return null;
    }

    return { endpoint, accessKey };
  } catch {
    return null;
  }
}

async function createIdentity(endpoint: string, accessKey: string): Promise<Response> {
  const url = `${endpoint}/identities?api-version=2023-10-01`;
  const date = new Date().toUTCString();
  
  const body = JSON.stringify({ createTokenWithScopes: [] });
  const contentHash = await sha256Base64(body);
  
  const stringToSign = `POST\n/identities?api-version=2023-10-01\n${date};${new URL(endpoint).host};${contentHash}`;
  const signature = await hmacSha256Base64(accessKey, stringToSign);
  
  return fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-ms-date': date,
      'x-ms-content-sha256': contentHash,
      'Authorization': `HMAC-SHA256 SignedHeaders=x-ms-date;host;x-ms-content-sha256&Signature=${signature}`
    },
    body
  });
}

async function generateToken(
  endpoint: string, 
  accessKey: string, 
  identityId: string, 
  scopes: string[]
): Promise<Response> {
  const url = `${endpoint}/identities/${identityId}/:issueAccessToken?api-version=2023-10-01`;
  const date = new Date().toUTCString();
  
  const body = JSON.stringify({ scopes });
  const contentHash = await sha256Base64(body);
  
  const path = `/identities/${identityId}/:issueAccessToken?api-version=2023-10-01`;
  const stringToSign = `POST\n${path}\n${date};${new URL(endpoint).host};${contentHash}`;
  const signature = await hmacSha256Base64(accessKey, stringToSign);
  
  return fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-ms-date': date,
      'x-ms-content-sha256': contentHash,
      'Authorization': `HMAC-SHA256 SignedHeaders=x-ms-date;host;x-ms-content-sha256&Signature=${signature}`
    },
    body
  });
}

async function sha256Base64(message: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return btoa(String.fromCharCode(...new Uint8Array(hashBuffer)));
}

async function hmacSha256Base64(key: string, message: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyData = Uint8Array.from(atob(key), c => c.charCodeAt(0));
  const messageData = encoder.encode(message);
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}

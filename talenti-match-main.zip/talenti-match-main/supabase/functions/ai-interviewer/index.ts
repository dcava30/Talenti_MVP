import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple in-memory rate limiter
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = { windowMs: 60000, maxRequests: 30 }; // 30 requests per minute (interviews need higher limit)

function checkRateLimit(identifier: string): { isLimited: boolean; resetAt: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || entry.resetAt <= now) {
    rateLimitStore.set(identifier, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return { isLimited: false, resetAt: now + RATE_LIMIT.windowMs };
  }
  
  if (entry.count >= RATE_LIMIT.maxRequests) {
    return { isLimited: true, resetAt: entry.resetAt };
  }
  
  entry.count++;
  return { isLimited: false, resetAt: entry.resetAt };
}

function getClientIP(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0].trim() 
    || req.headers.get('x-real-ip') 
    || req.headers.get('cf-connecting-ip') 
    || 'unknown';
}

interface InterviewMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface CAGContext {
  jobTitle: string;
  jobDescription?: string;
  requirements?: {
    skills?: string[];
    experience?: string[];
    qualifications?: string[];
    responsibilities?: string[];
  };
  orgValues?: string[];
  companyName?: string;
  candidateContext?: {
    skills?: string[];
    experienceYears?: number;
    recentRoles?: string[];
  };
  competenciesCovered?: string[];
  competenciesToCover?: string[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check rate limit by IP first (before auth to prevent brute force)
    const clientIP = getClientIP(req);
    const ipRateLimitResult = checkRateLimit(`ip:${clientIP}`);
    
    if (ipRateLimitResult.isLimited) {
      const retryAfter = Math.ceil((ipRateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: "Too many requests. Please try again later.", retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": retryAfter.toString()
          } 
        }
      );
    }

    // Verify user authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized - authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the JWT and get user claims
    const token = authHeader.replace('Bearer ', '');
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error('Auth verification failed:', claimsError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized - invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userId = claimsData.claims.sub as string;
    console.log(`AI Interviewer - Authenticated user: ${userId}`);

    // Add per-user rate limiting
    const userRateLimitResult = checkRateLimit(`user:${userId}`);
    if (userRateLimitResult.isLimited) {
      const retryAfter = Math.ceil((userRateLimitResult.resetAt - Date.now()) / 1000);
      console.log(`Rate limit exceeded for user: ${userId}`);
      return new Response(
        JSON.stringify({ error: "Too many requests. Please try again later.", retryAfter }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            "Content-Type": "application/json",
            "Retry-After": retryAfter.toString()
          } 
        }
      );
    }
    const { 
      messages, 
      jobTitle, 
      companyName, 
      currentQuestionIndex,
      isPractice,
      // CAG context fields
      jobDescription,
      requirements,
      orgValues,
      candidateContext,
      competenciesCovered,
      competenciesToCover,
    } = await req.json();
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Build enhanced CAG system prompt
    let systemPrompt = `You are a professional AI interviewer conducting a job interview for the position of ${jobTitle || "a role"} at ${companyName || "the company"}.

## Your Personality
- Professional yet warm and encouraging
- Clear and articulate
- Actively listen and ask relevant follow-up questions
- Provide brief acknowledgments before moving to next topics`;

    // Add job requirements context
    if (requirements && Object.keys(requirements).length > 0) {
      systemPrompt += `

## Job Requirements to Assess`;
      if (requirements.skills?.length) {
        systemPrompt += `
### Required Skills: ${requirements.skills.join(", ")}`;
      }
      if (requirements.experience?.length) {
        systemPrompt += `
### Experience Requirements:
${requirements.experience.map((e: string) => `- ${e}`).join("\n")}`;
      }
      if (requirements.responsibilities?.length) {
        systemPrompt += `
### Key Responsibilities:
${requirements.responsibilities.slice(0, 5).map((r: string) => `- ${r}`).join("\n")}`;
      }
    }

    // Add org values for culture fit assessment
    if (orgValues?.length) {
      systemPrompt += `

## Company Values to Evaluate Against
${orgValues.map((v: string, i: number) => `${i + 1}. ${v}`).join("\n")}
When assessing culture fit, specifically evaluate alignment with these values.`;
    }

    // Add candidate context (de-identified for bias reduction)
    if (candidateContext && !isPractice) {
      systemPrompt += `

## Candidate Background (for context only - do not reveal you know this)
- Skills: ${candidateContext.skills?.join(", ") || "Not specified"}
- Years of Experience: ${candidateContext.experienceYears || "Not specified"}
- Recent Roles: ${candidateContext.recentRoles?.slice(0, 3).join(", ") || "Not specified"}
Use this context to ask relevant follow-up questions and explore their experience more deeply.`;
    }

    // Add competency tracking
    if (competenciesToCover?.length || competenciesCovered?.length) {
      systemPrompt += `

## Interview Progress`;
      if (competenciesCovered?.length) {
        systemPrompt += `
- Competencies Already Covered: ${competenciesCovered.join(", ")}`;
      }
      if (competenciesToCover?.length) {
        systemPrompt += `
- Competencies Still to Cover: ${competenciesToCover.join(", ")}`;
      }
      systemPrompt += `

Prioritize covering uncovered competencies. If a competency has been explored well, move to unexplored areas.`;
    }

    // Add interview guidelines
    systemPrompt += `

## Interview Guidelines
- Keep responses concise (2-4 sentences for transitions, 1-2 sentences for acknowledgments)
- Ask one question at a time
- Adapt follow-up questions based on candidate responses
- If their answer is vague, ask clarifying follow-ups
- Reference their background to make questions relevant
- After ${isPractice ? "4-5" : "5-6"} exchanges, wrap up the interview professionally

Current question index: ${currentQuestionIndex || 0}

If this is the start (question 0), greet the candidate warmly and ask them to introduce themselves.
If nearing the end (question ${isPractice ? "4" : "5"}+), thank them and conclude the interview.`;

    if (isPractice) {
      systemPrompt += `

## Practice Mode
This is a practice interview. Be encouraging and provide brief, helpful tips after each response.`;
    }

    const conversationMessages: InterviewMessage[] = [
      { role: "system", content: systemPrompt },
      ...messages.map((m: { role: string; content: string }) => ({
        role: m.role === "ai" ? "assistant" : m.role,
        content: m.content,
      })),
    ];

    console.log("AI Interviewer request - Question:", currentQuestionIndex, "Practice:", isPractice);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: conversationMessages,
        max_tokens: 400,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits depleted. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("Failed to get AI response");
    }

    const data = await response.json();
    const aiMessage = data.choices?.[0]?.message?.content;

    if (!aiMessage) {
      throw new Error("No response from AI");
    }

    // Detect which competencies were covered in this exchange
    let detectedCompetencies: string[] = [];
    if (competenciesToCover?.length && messages.length > 0) {
      const lastUserMessage = messages.filter((m: any) => m.role === "user").pop();
      if (lastUserMessage) {
        const content = lastUserMessage.content.toLowerCase();
        detectedCompetencies = competenciesToCover.filter((comp: string) => 
          content.includes(comp.toLowerCase()) || 
          aiMessage.toLowerCase().includes(comp.toLowerCase())
        );
      }
    }

    return new Response(
      JSON.stringify({ 
        message: aiMessage,
        detectedCompetencies,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("AI interviewer error:", error);
    return new Response(
      JSON.stringify({ error: "An error occurred processing your request" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});